import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowRight, Camera, Download, Sparkles } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { rooms } from "@/lib/business";
import { saveRoomBrief } from "@/lib/visualiser-brief";

export const Route = createFileRoute("/reimagine")({
  head: () => ({
    meta: [
      { title: "Reimagine your room — LuxeInfra" },
      {
        name: "description",
        content:
          "Start with a room photo, describe your ideas, and prepare a personal interior design concept.",
      },
    ],
  }),
  component: Reimagine,
});
type Status = {
  enabled: boolean;
  provider: "openai" | "huggingface";
  providerLabel: string;
  remaining: number;
  message: string;
};
type Job = {
  id: string;
  state: "generating" | "completed" | "failed";
  error?: string;
  original?: string;
  concept?: string;
  expiresAt: number;
};
const styles = ["Warm minimal", "Modern classic", "Natural & relaxed", "Help me choose"];
async function jsonResponse<T>(response: Response): Promise<T> {
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || "Please try again later.");
  return body;
}
async function imageFile(url: string, name: string) {
  const response = await fetch(url);
  if (!response.ok) throw new Error("This image has expired. Please start a new brief.");
  return new File([await response.blob()], name, { type: "image/jpeg" });
}
function Reimagine() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<Status | null>(null);
  const [serviceError, setServiceError] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [brief, setBrief] = useState({
    room: "Living & dining",
    style: "Warm minimal",
    length: "",
    width: "",
    height: "",
    unit: "feet",
    changes: "",
    keep: "",
  });
  const [review, setReview] = useState(false);
  const [consent, setConsent] = useState(false);
  const [job, setJob] = useState<Job | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [split, setSplit] = useState(50);
  const [pollVersion, setPollVersion] = useState(0);
  const [uncertainId, setUncertainId] = useState("");
  const locked = useRef(false);
  const reviewHeading = useRef<HTMLHeadingElement>(null);
  const photoVersion = useRef(0);
  const update = (key: keyof typeof brief, value: string) =>
    setBrief((b) => ({ ...b, [key]: value }));
  async function choosePhoto(file?: File) {
    const version = ++photoVersion.current;
    setPhoto(null);
    setError("");
    if (!file) return;
    if (
      !["image/jpeg", "image/png"].includes(file.type) ||
      !file.size ||
      file.size > 8 * 1024 * 1024
    ) {
      setError("Choose a JPG or PNG room photo up to 8 MB.");
      return;
    }
    try {
      const bitmap = await createImageBitmap(file);
      const valid =
        bitmap.width >= 256 && bitmap.height >= 256 && bitmap.width * bitmap.height <= 40_000_000;
      bitmap.close();
      if (version !== photoVersion.current) return;
      if (!valid) {
        setError(
          "Choose a photo at least 256 pixels on each side and no larger than 40 megapixels.",
        );
        return;
      }
      setPhoto(file);
    } catch {
      if (version === photoVersion.current)
        setError("This photo could not be opened. Try another JPG or PNG.");
    }
  }
  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/visualiser/status", { signal: controller.signal })
      .then(jsonResponse<Status>)
      .then(setStatus)
      .catch((e) => {
        if (!controller.signal.aborted)
          setServiceError("The image service is unavailable. You can still prepare a room brief.");
      });
    return () => controller.abort();
  }, []);
  useEffect(() => {
    if (!photo) {
      setPreview("");
      return;
    }
    const url = URL.createObjectURL(photo);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);
  useEffect(() => {
    if (review) reviewHeading.current?.focus();
  }, [review]);
  useEffect(() => {
    if (!job || job.state !== "generating") return;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    async function poll() {
      try {
        const result = await fetch(`/api/visualiser/jobs/${job!.id}`, {
          signal: controller.signal,
        }).then(jsonResponse<Job>);
        if (controller.signal.aborted) return;
        setJob(result);
        if (result.state === "generating") timer = setTimeout(poll, 2000);
      } catch {
        if (!controller.signal.aborted)
          setError(
            "We couldn’t check the result. Check its status below before starting another attempt.",
          );
      }
    }
    timer = setTimeout(poll, 1000);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [job?.id, job?.state, pollVersion]);
  function validate() {
    if (!photo) return "Choose a room photo first.";
    if (
      !["image/jpeg", "image/png"].includes(photo.type) ||
      photo.size > 8 * 1024 * 1024 ||
      !photo.size
    )
      return "Choose a JPG or PNG room photo up to 8 MB.";
    const max = brief.unit === "feet" ? [100, 100, 30] : [30, 30, 10];
    if (
      [brief.length, brief.width, brief.height].some(
        (v, i) => !Number.isFinite(Number(v)) || Number(v) < 1 || Number(v) > max[i],
      )
    )
      return `Enter room dimensions between 1 and ${max[0]} ${brief.unit}, and ceiling height between 1 and ${max[2]} ${brief.unit}.`;
    if (brief.changes.trim().length < 10)
      return "Tell us a little more about your ideas (at least 10 characters).";
    return "";
  }
  async function generate() {
    if (locked.current || job || uncertainId || !consent || !status?.enabled || !status.remaining)
      return;
    const invalid = validate();
    if (invalid) {
      setError(invalid);
      return;
    }
    locked.current = true;
    setBusy(true);
    setError("");
    const id = crypto.randomUUID();
    const data = new FormData();
    data.append(
      "brief",
      JSON.stringify({
        ...brief,
        id,
        length: Number(brief.length),
        width: Number(brief.width),
        height: Number(brief.height),
        consent,
        provider: status.provider,
      }),
    );
    data.append("photo", photo!);
    try {
      const response = await fetch("/api/visualiser/jobs", { method: "POST", body: data });
      if (!response.ok) {
        const body = await response.json();
        setError(body.error || "The request could not start.");
        return;
      }
      setJob(await jsonResponse<Job>(response));
      setStatus((s) => (s ? { ...s, remaining: Math.max(0, s.remaining - 1) } : s));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to start the concept.");
      // A lost response may still represent a paid generation. Never automatically retry.
      setUncertainId(id);
    } finally {
      locked.current = false;
      setBusy(false);
    }
  }
  async function recover() {
    setError("");
    setBusy(true);
    try {
      const response = await fetch(`/api/visualiser/jobs/${uncertainId}`);
      if (response.status === 404) {
        setUncertainId("");
        setError(
          "No active result was found. It may have expired. No new generation was started; check your account usage before trying again.",
        );
        setStatus(await fetch("/api/visualiser/status").then(jsonResponse<Status>));
        return;
      }
      setJob(await jsonResponse<Job>(response));
      setUncertainId("");
    } catch (e) {
      setError(
        `${e instanceof Error ? e.message : "Status unavailable."} No new generation was requested.`,
      );
    } finally {
      setBusy(false);
    }
  }
  function notes() {
    return [
      `ROOM DESIGN BRIEF`,
      `${brief.room} · ${brief.style}`,
      `User-supplied dimensions: ${brief.length} × ${brief.width} ${brief.unit}; ceiling ${brief.height} ${brief.unit}.`,
      `Ideas: ${brief.changes.trim()}`,
      brief.keep.trim() ? `Keep: ${brief.keep.trim()}` : "",
      job?.state === "completed"
        ? "Attached AI-generated concept is inspiration only. Dimensions, layout, materials, cost and feasibility need designer verification."
        : "No AI concept generated. Please review the attached room photo and requirements.",
    ]
      .filter(Boolean)
      .join("\n");
  }
  async function handoff() {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setError("");
    try {
      const files =
        job?.state === "completed"
          ? await Promise.all([
              imageFile(job.original!, "My-room.jpg"),
              imageFile(job.concept!, "AI-concept-inspiration-only.jpg"),
            ])
          : [photo!];
      saveRoomBrief({ room: brief.room, style: brief.style, notes: notes(), files });
      await navigate({ to: "/plan", search: { roomBrief: "1" } });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Please try again.");
    } finally {
      locked.current = false;
      setBusy(false);
    }
  }
  async function download() {
    setError("");
    try {
      const file = await imageFile(job!.concept!, "LuxeInfra-AI-concept.jpg");
      const url = URL.createObjectURL(file);
      const a = document.createElement("a");
      a.href = url;
      a.download = file.name;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Download unavailable.");
    }
  }
  async function reset() {
    setBusy(true);
    setError("");
    try {
      if (job) {
        const response = await fetch(`/api/visualiser/jobs/${job.id}`, { method: "DELETE" });
        if (response.status !== 404 && response.status !== 401) await jsonResponse(response);
      }
      setJob(null);
      setUncertainId("");
      setReview(false);
      setConsent(false);
      setStatus(await fetch("/api/visualiser/status").then(jsonResponse<Status>));
    } catch {
      setError(
        "Could not clear the previous concept. Please check again before generating another.",
      );
    } finally {
      setBusy(false);
    }
  }
  const generating = job?.state === "generating";
  return (
    <PageShell>
      <section className="wrap section reimagine-intro">
        <div>
          <span className="eyebrow">YOUR ROOM. A NEW POSSIBILITY.</span>
          <h1>
            See the room.
            <br />
            <em>Imagine the change.</em>
          </h1>
          <p>A photograph. A few ideas. The beginning of a space that feels more like you.</p>
        </div>
        <ol className="ai-steps">
          <li>
            <span>01</span> Share your space
          </li>
          <li>
            <span>02</span> Shape the idea
          </li>
          <li>
            <span>03</span> Bring it to your brief
          </li>
        </ol>
      </section>
      <section className="wrap ai-workspace" aria-label="Room visualiser">
        <aside className="ai-photo-panel">
          <div className="ai-photo">
            {preview ? (
              <img src={preview} alt="Your selected room, before redesign" />
            ) : (
              <div>
                <Camera size={40} strokeWidth={1} />
                <h2>
                  Every possibility
                  <br />
                  starts here.
                </h2>
                <p>Use a clear, wide photo taken from a corner of your room.</p>
              </div>
            )}
          </div>
          <div className="ai-photo-caption">
            <span className="eyebrow">
              {preview ? "YOUR ROOM / ORIGINAL" : "A LITTLE LIGHT GOES A LONG WAY"}
            </span>
            <p>
              Include the floor, windows and walls. Avoid people, documents and personal details.
              JPG or PNG · up to 8 MB · at least 256 × 256 pixels.
            </p>
          </div>
        </aside>
        <div className="ai-form-panel">
          <div className="ai-status" role="status">
            <Sparkles size={18} />
            <p>{serviceError || status?.message || "Checking image service…"}</p>
          </div>
          {!review ? (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const message = validate();
                setError(message);
                if (!message) setReview(true);
              }}
            >
              <span className="eyebrow">01 / MAKE IT PERSONAL</span>
              <h2>Tell us what could be.</h2>
              <label className="ai-field">
                Your room photo
                <input
                  type="file"
                  accept="image/jpeg,image/png"
                  required
                  onChange={(e) => {
                    void choosePhoto(e.target.files?.[0]);
                  }}
                />
              </label>
              <div className="ai-two">
                <label className="ai-field">
                  Which room?
                  <select value={brief.room} onChange={(e) => update("room", e.target.value)}>
                    {rooms.map((room) => (
                      <option key={room}>{room}</option>
                    ))}
                  </select>
                </label>
                <label className="ai-field">
                  Design direction
                  <select value={brief.style} onChange={(e) => update("style", e.target.value)}>
                    {styles.map((style) => (
                      <option key={style}>{style}</option>
                    ))}
                  </select>
                </label>
              </div>
              <label className="ai-field">
                Dimension unit
                <select value={brief.unit} onChange={(e) => update("unit", e.target.value)}>
                  <option value="feet">Feet</option>
                  <option value="metres">Metres</option>
                </select>
              </label>
              <div className="ai-dimensions">
                {(
                  [
                    ["length", "Length"],
                    ["width", "Width"],
                    ["height", "Ceiling height"],
                  ] as const
                ).map(([key, label]) => (
                  <label className="ai-field" key={key}>
                    {label}
                    <input
                      type="number"
                      min="1"
                      max={
                        brief.unit === "feet"
                          ? key === "height"
                            ? 30
                            : 100
                          : key === "height"
                            ? 10
                            : 30
                      }
                      step="0.1"
                      inputMode="decimal"
                      required
                      value={brief[key]}
                      onChange={(e) => update(key, e.target.value)}
                      placeholder={key === "height" ? "e.g. 9" : "e.g. 12"}
                    />
                  </label>
                ))}
              </div>
              <label className="ai-field">
                What would you love to change?
                <textarea
                  rows={4}
                  required
                  minLength={10}
                  maxLength={1000}
                  value={brief.changes}
                  onChange={(e) => update("changes", e.target.value)}
                  placeholder="A warm, uncluttered living room with concealed storage, soft lighting and a reading corner…"
                />
              </label>
              <label className="ai-field">
                What should stay? <span className="ai-optional">Optional</span>
                <textarea
                  rows={2}
                  maxLength={400}
                  value={brief.keep}
                  onChange={(e) => update("keep", e.target.value)}
                  placeholder="Keep the existing sofa, windows and flooring…"
                />
              </label>
              <button className="button" type="submit">
                Review my room brief <ArrowRight size={17} />
              </button>
              <p className="ai-fine">Selecting a photo does not send it to an AI service.</p>
            </form>
          ) : (
            <div>
              <span className="eyebrow">02 / YOUR DIRECTION</span>
              <h2 ref={reviewHeading} tabIndex={-1}>
                A space, rethought.
              </h2>
              <dl className="ai-review">
                <div>
                  <dt>Space & style</dt>
                  <dd>
                    {brief.room} · {brief.style}
                  </dd>
                </div>
                <div>
                  <dt>Dimensions you provided</dt>
                  <dd>
                    {brief.length} × {brief.width} {brief.unit} · ceiling {brief.height}{" "}
                    {brief.unit}
                  </dd>
                </div>
                <div>
                  <dt>Your ideas</dt>
                  <dd>{brief.changes}</dd>
                </div>
                {brief.keep && (
                  <div>
                    <dt>Keep in place</dt>
                    <dd>{brief.keep}</dd>
                  </div>
                )}
              </dl>
              <p className="ai-fine">
                AI concepts are visual inspiration. They may alter details or proportions;
                dimensions do not guarantee an accurate layout or furniture fit. A designer must
                verify the proposal.
              </p>
              {!job && !uncertainId && (
                <>
                  <label className="ai-consent">
                    <input
                      type="checkbox"
                      checked={consent}
                      onChange={(e) => setConsent(e.target.checked)}
                      disabled={!status?.enabled}
                    />
                    <span>
                      I have permission to use this photo and agree to send it, my room details and
                      instructions to {status?.providerLabel || "the connected image provider"} to
                      create a concept. <Link to="/privacy">About my information</Link>
                    </span>
                  </label>
                  <button
                    className="button"
                    disabled={busy || !consent || !status?.enabled || !status.remaining}
                    onClick={generate}
                  >
                    <Sparkles size={18} />
                    {busy ? "Starting your concept…" : "Generate my room concept"}
                  </button>
                  {!status?.enabled && (
                    <p className="ai-fine">
                      Generation will become available when the studio connects an image-generation
                      account.
                    </p>
                  )}
                </>
              )}
              {generating && (
                <div className="ai-progress" role="status">
                  <Sparkles size={24} />
                  <h3>Your idea is taking shape.</h3>
                  <p>
                    This can take a few minutes. Keep this page open. We won’t start another
                    generation automatically.
                  </p>
                </div>
              )}
              {job?.state === "failed" && (
                <p role="alert" className="ai-error">
                  {job.error}
                </p>
              )}
              {uncertainId && (
                <button className="button" disabled={busy} onClick={recover}>
                  Check the existing request
                </button>
              )}
              {generating && error && (
                <button
                  className="text-link"
                  onClick={() => {
                    setError("");
                    setPollVersion((v) => v + 1);
                  }}
                >
                  Check result again
                </button>
              )}
              {!generating && (
                <div className="ai-actions">
                  <button className="button outline" disabled={busy} onClick={handoff}>
                    {job?.state === "completed"
                      ? "Use this concept in my brief"
                      : "Add this room to my project brief"}
                    <ArrowRight size={17} />
                  </button>
                  {!job && !uncertainId && (
                    <button
                      className="text-link"
                      disabled={busy}
                      onClick={() => {
                        setReview(false);
                        setConsent(false);
                      }}
                    >
                      Edit room details
                    </button>
                  )}
                </div>
              )}
              {job && (
                <button className="text-link" disabled={busy} onClick={reset}>
                  {generating ? "Cancel and clear this attempt" : "Clear concept & edit details"}
                </button>
              )}
            </div>
          )}
          {error && (
            <p className="ai-error" role="alert">
              {error}
            </p>
          )}
        </div>
      </section>
      {job?.state === "completed" && (
        <section className="wrap section ai-result" aria-label="Your AI room concept">
          <span className="eyebrow">03 / ONE POSSIBLE DIRECTION</span>
          <h2>
            Your room. <em>A fresh perspective.</em>
          </h2>
          <p>
            Drag to compare. Images retain their own proportions; this is not a measured overlay.
          </p>
          <div className="ai-comparison">
            <img src={job.original} alt="Original room photograph" />
            <div style={{ clipPath: `inset(0 0 0 ${split}%)` }}>
              <img src={job.concept} alt="AI-generated room design concept, for inspiration only" />
            </div>
            <span className="ai-divider" style={{ left: `${split}%` }} />
            <b className="ai-original-label">Original</b>
            <b className="ai-concept-label">AI concept</b>
          </div>
          <label className="ai-field">
            Compare original and concept
            <input
              type="range"
              min="0"
              max="100"
              value={split}
              onChange={(e) => setSplit(Number(e.target.value))}
              aria-valuetext={`${split}% original, ${100 - split}% AI concept`}
            />
          </label>
          <button className="button outline" onClick={download}>
            <Download size={17} />
            Download AI concept
          </button>
          <p className="ai-fine">
            Download or add the concept to your project brief before leaving. Preview images expire
            after 30 minutes. A restart clears them sooner.
          </p>
        </section>
      )}
      <section className="wrap ai-explainer">
        <div>
          <span className="eyebrow">FROM POSSIBILITY TO A PLAN</span>
          <h2>
            An idea to explore.
            <br />
            <em>A designer to make it yours.</em>
          </h2>
        </div>
        <p>
          Your concept starts a conversation. We’ll review the actual dimensions, practical layout,
          materials and project scope with you before recommending a design or quote.
        </p>
      </section>
    </PageShell>
  );
}
