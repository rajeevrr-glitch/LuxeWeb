import { useEffect, useRef, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Check,
  ArrowLeft,
  House,
  CookingPot,
  DoorOpen,
  BedDouble,
  MessageCircle,
} from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { ContactFields, ContactDisclosure, EnquiryHandoff } from "@/components/EnquiryContact";
import { emptyContact, validateLead, leadMessage, type LeadContact } from "@/lib/sales-funnel";
import { homeConfigurations } from "@/lib/estimate";
import {
  createWelcomeTracker,
  welcomeIsEligible,
  welcomeShouldOpen,
  welcomeIsTimely,
} from "@/lib/welcome";
import { planningJourney } from "@/lib/journey";
import { openWhatsAppRequest } from "@/lib/whatsapp";
import { useEnquiryDelivery } from "@/hooks/use-enquiry-delivery";
import {
  AutomaticEnquiryReceipt,
  AutomaticDeliveryError,
} from "@/components/EnquiryDeliveryFeedback";
import living from "@/assets/hero-living.jpg";
import kitchen from "@/assets/kitchen.jpg";
import wardrobe from "@/assets/wardrobe.jpg";
import bedroom from "@/assets/bedroom.jpg";

const tracker = createWelcomeTracker({
  getItem: (key) => window.sessionStorage.getItem(key),
  setItem: (key, value) => window.sessionStorage.setItem(key, value),
});
const projects = [
  {
    id: "home",
    title: "Full home interiors",
    short: "Whole home",
    scope: "Whole home",
    image: living,
    Icon: House,
    line: ["Full home", "interiors."],
    detail: "Kitchens, bedrooms and living spaces planned together.",
  },
  {
    id: "kitchen",
    title: "Modular kitchen",
    short: "Kitchen",
    scope: "Modular interiors",
    image: kitchen,
    Icon: CookingPot,
    line: ["A kitchen that", "works for you."],
    detail: "Discuss your layout, storage and finishes.",
  },
  {
    id: "wardrobes",
    title: "Wardrobes & storage",
    short: "Wardrobes",
    scope: "Modular interiors",
    image: wardrobe,
    Icon: DoorOpen,
    line: ["Room for", "everything."],
    detail: "Plan the shelves, drawers and hanging space you need.",
  },
  {
    id: "room",
    title: "One or more rooms",
    short: "Selected rooms",
    scope: "Selected rooms",
    image: bedroom,
    Icon: BedDouble,
    line: ["Start with", "one room."],
    detail: "Tell us what you want to change in your space.",
  },
] as const;
type ProjectId = (typeof projects)[number]["id"] | "guidance";

export function WelcomeExperience() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [selection, setSelection] = useState<ProjectId | "">("");
  const [configuration, setConfiguration] = useState("");
  const [contact, setContact] = useState<LeadContact>({ ...emptyContact });
  const [error, setError] = useState("");
  const delivery = useEnquiryDelivery();
  const resetDelivery = delivery.reset;
  const heading = useRef<HTMLHeadingElement>(null);
  const previousPath = useRef(pathname);
  const interacted = useRef(false);
  const eligible = welcomeIsEligible(pathname);
  const project = projects.find((item) => item.id === selection);
  const scene = project || projects[0];

  useEffect(() => {
    if (!eligible) return;
    function openFromHeader() {
      interacted.current = true;
      tracker.markSeen();
      setOpen(true);
    }
    window.addEventListener("luxe-open-quote", openFromHeader);
    return () => window.removeEventListener("luxe-open-quote", openFromHeader);
  }, [eligible]);

  useEffect(() => {
    if (!eligible) return;
    const forced = new URLSearchParams(window.location.search).get("welcome") === "1";
    if (!welcomeShouldOpen(pathname, tracker.hasSeen(), interacted.current, forced)) return;
    let timer: ReturnType<typeof setTimeout>;
    let cancelled = false;
    const started = Date.now();
    function invite() {
      if (cancelled || !welcomeShouldOpen(pathname, tracker.hasSeen(), interacted.current, forced))
        return;
      if (
        !welcomeIsTimely(
          Date.now() - started,
          window.scrollY > Math.min(320, window.innerHeight / 2),
          forced,
        )
      ) {
        timer = setTimeout(invite, 1500);
        return;
      }
      // Do not cover a menu, image viewer, active text entry or a background tab.
      const active = document.activeElement;
      const busy =
        document.hidden ||
        active?.matches("input, textarea, select, [contenteditable='true']") ||
        document.querySelector(
          '[role="dialog"][data-state="open"], .mobile-nav, [aria-controls="spaces-menu"][aria-expanded="true"]',
        );
      if (busy) {
        timer = setTimeout(invite, 1800);
        return;
      }
      tracker.markSeen();
      setOpen(true);
    }
    timer = setTimeout(invite, forced ? 800 : 12000);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [pathname, eligible]);

  useEffect(() => {
    if (previousPath.current === pathname) return;
    previousPath.current = pathname;
    resetDelivery();
    setOpen(false);
    setStep(0);
    setContact({ ...emptyContact });
    setError("");
  }, [pathname, resetDelivery]);

  function changeOpen(next: boolean) {
    if (!next && delivery.sending) return;
    interacted.current = true;
    if (next) tracker.markSeen();
    setOpen(next);
    if (!next) {
      delivery.reset();
      setContact({ ...emptyContact });
      setStep(0);
      setError("");
    }
  }
  function go(next: number) {
    setStep(next);
    setError("");
    requestAnimationFrame(() => {
      heading.current?.focus({ preventScroll: true });
      heading.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }
  function update(key: keyof LeadContact, value: string) {
    delivery.reset();
    setContact((old) => ({ ...old, [key]: value }));
    setError("");
  }
  async function prepare(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (delivery.sending || delivery.checking) return;
    const invalid = validateLead(contact);
    if (invalid) {
      setError(invalid);
      return;
    }
    if (delivery.enabled) {
      const accepted = await delivery.submit({
        kind: "quote",
        name: contact.name,
        phone: contact.phone,
        city: contact.city,
        message: leadMessage(contact, context),
        consent: true,
      });
      if (accepted) go(2);
      return;
    }
    openWhatsAppRequest(leadMessage(contact, context));
    go(2);
  }
  if (!eligible) return null;
  const context =
    "Interested in: " +
    (project?.short || "Design guidance") +
    (selection === "home" && configuration ? "\nHome type: " + configuration : "");
  return (
    <>
      <Dialog open={open} onOpenChange={changeOpen}>
        <DialogContent
          className="luxe-commerce lw-dialog"
          data-step={step}
          aria-busy={delivery.sending}
          onEscapeKeyDown={(event) => {
            if (delivery.sending) event.preventDefault();
          }}
          onInteractOutside={(event) => {
            if (delivery.sending) event.preventDefault();
          }}
          onOpenAutoFocus={(event) => {
            event.preventDefault();
            heading.current?.focus();
          }}
          onCloseAutoFocus={(event) => {
            event.preventDefault();
            const target = document.querySelector<HTMLAnchorElement>('header a[href="/callback"]');
            target?.focus({ preventScroll: true });
          }}
        >
          <div className="lw-scene">
            <img
              key={scene.id}
              src={scene.image}
              alt={`${scene.short} design inspiration`}
              width="700"
              height="900"
            />
            <div className="lw-brand">
              LUXE<span>INFRA</span>
              <small>INTERIORS, CONSIDERED.</small>
            </div>
            <div className="lw-scene-copy" key={scene.id + "-copy"}>
              <span>LuxeInfra interiors</span>
              <p>
                {scene.line[0]}
                <br />
                <em>{scene.line[1]}</em>
              </p>
              <small>{scene.detail}</small>
            </div>
            <span className="lw-reference">DESIGN INSPIRATION</span>
          </div>
          <div className="lw-content">
            <div
              className="lw-progress"
              aria-label={step < 2 ? `Quote request step ${step + 1} of 2` : "Continue in WhatsApp"}
            >
              {["Your space", "Your details"].map((label, i) => (
                <span
                  key={label}
                  aria-current={i === step ? "step" : undefined}
                  data-complete={step > i}
                >
                  <b>{step > i ? <Check size={10} /> : i + 1}</b>
                  {label}
                </span>
              ))}
            </div>
            <div className="lw-step" key={step}>
              <DialogTitle ref={heading} tabIndex={-1} className="lw-title">
                {step === 0
                  ? "What would you like done?"
                  : step === 1
                    ? "Where can we reach you?"
                    : delivery.result
                      ? "Request submitted"
                      : "Continue in WhatsApp"}
              </DialogTitle>
              <DialogDescription className="lw-description">
                {step === 0
                  ? "Choose your project. We’ll help with the details."
                  : step === 1
                    ? "We’ll include your project and contact details in the message."
                    : delivery.result
                      ? "Your request has been saved for our team."
                      : "Press Send in WhatsApp to share your request with our team."}
              </DialogDescription>
              {step === 0 && (
                <>
                  <div className="lw-projects" role="group" aria-label="Choose your project">
                    {projects.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        aria-pressed={selection === item.id}
                        onClick={() => {
                          if (selection !== item.id || configuration) delivery.reset();
                          setSelection(item.id);
                          setConfiguration("");
                          setError("");
                        }}
                      >
                        <img src={item.image} alt="" width="80" height="80" />
                        <span>
                          <item.Icon size={16} />
                          <strong>{item.title}</strong>
                        </span>
                        <Check size={12} className="lw-project-tick" />
                      </button>
                    ))}
                  </div>
                  {selection === "home" && (
                    <fieldset className="lw-home-types">
                      <legend>
                        Your home type <span>Optional</span>
                      </legend>
                      <div>
                        {homeConfigurations.map((config) => (
                          <button
                            type="button"
                            key={config}
                            aria-pressed={configuration === config}
                            onClick={() => {
                              if (configuration !== config) delivery.reset();
                              setConfiguration(config);
                            }}
                          >
                            {config}
                          </button>
                        ))}
                      </div>
                    </fieldset>
                  )}
                  <button
                    type="button"
                    className="lw-guidance"
                    aria-pressed={selection === "guidance"}
                    onClick={() => {
                      if (selection !== "guidance" || configuration) delivery.reset();
                      setSelection("guidance");
                      setConfiguration("");
                      setError("");
                    }}
                  >
                    Not sure? I’d like some advice
                    {selection === "guidance" && <Check size={13} />}
                  </button>
                  {error && (
                    <p className="lx-error" role="alert">
                      {error}
                    </p>
                  )}
                  <button
                    type="button"
                    className="button lw-primary"
                    onClick={() => {
                      if (!selection) {
                        setError("Choose a project, or select I’d like some advice.");
                        return;
                      }
                      go(1);
                    }}
                  >
                    <MessageCircle size={17} />
                    Add my details
                  </button>
                  <p className="lw-soft-note">No floor plan needed. Start with what you know.</p>
                  <div className="lw-browse">
                    <button type="button" onClick={() => changeOpen(false)}>
                      I’m just exploring
                    </button>
                    <Link
                      to="/estimate"
                      search={{
                        scope: project?.scope || "Whole home",
                        module:
                          selection === "kitchen"
                            ? "Kitchen"
                            : selection === "wardrobes"
                              ? "Wardrobes"
                              : undefined,
                        configuration:
                          selection === "home" && configuration ? configuration : undefined,
                      }}
                      onClick={() => changeOpen(false)}
                    >
                      {planningJourney().label}
                    </Link>
                  </div>
                </>
              )}
              {step === 1 && (
                <form noValidate onSubmit={prepare} className="lw-form">
                  <div className="lw-selection">
                    <span>
                      <Check size={13} />
                      {project?.short || "Design guidance"}
                      {configuration ? " · " + configuration : ""}
                    </span>
                    <button type="button" onClick={() => go(0)} disabled={delivery.sending}>
                      <ArrowLeft size={12} /> Change
                    </button>
                  </div>
                  <ContactFields value={contact} onChange={update} disabled={delivery.sending} />
                  {error && (
                    <p className="lx-error" role="alert">
                      {error}
                    </p>
                  )}
                  <AutomaticDeliveryError
                    error={delivery.error}
                    message={leadMessage(contact, context)}
                    pendingReference={delivery.pendingReference}
                  />
                  <button
                    type="submit"
                    className="button lw-primary"
                    disabled={delivery.checking || delivery.sending}
                    aria-busy={delivery.sending}
                  >
                    <MessageCircle size={17} />{" "}
                    {delivery.sending
                      ? "Submitting…"
                      : delivery.checking
                        ? "Checking availability…"
                        : delivery.enabled
                          ? "Send my quote request"
                          : "Continue in WhatsApp"}
                  </button>
                  <ContactDisclosure direct automatic={delivery.enabled} />
                </form>
              )}
              {step === 2 &&
                (delivery.result ? (
                  <AutomaticEnquiryReceipt result={delivery.result} />
                ) : (
                  <EnquiryHandoff
                    opened
                    title="Your message is ready."
                    message={leadMessage(contact, context)}
                    onEdit={() => go(1)}
                  />
                ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
