import { Link } from "@tanstack/react-router";
import { Gift, Handshake, Sparkles } from "lucide-react";
import { festiveOffer, getFestiveState } from "@/lib/campaigns";
import home from "@/assets/ideas/living/03.jpg";
import office from "@/assets/ideas/office/02.jpg";

export function PromotionBar() {
  const state = getFestiveState();
  return (
    <div className="lc-promo-bar">
      <div className="wrap">
        <span className="lc-promo-signature">A little more room for beautiful.</span>
        {state !== "unavailable" ? (
          <Link to="/offers" className="lc-promo-message">
            <Gift size={15} aria-hidden="true" />
            <span>
              Festive season <strong>{festiveOffer.percent}% off</strong>
            </span>
            <span className="lc-promo-pill">{state === "preview" ? "Preview" : "View offer"}</span>
          </Link>
        ) : (
          <Link to="/design-ideas" className="lc-promo-message">
            <Sparkles size={15} aria-hidden="true" /> Fresh inspiration for your home
          </Link>
        )}
        <Link to="/partner-with-us" className="lc-promo-partner">
          Partner with us
        </Link>
      </div>
    </div>
  );
}

export function FestiveFeature() {
  const state = getFestiveState();
  if (state === "unavailable") return null;
  return (
    <section className="wrap lc-festive" aria-labelledby="festive-title">
      <div className="lc-festive-photo">
        <img
          src={home}
          alt="A warm living room with natural textures, for design inspiration"
          loading="lazy"
          width="900"
          height="675"
        />
        <span>MAKE ROOM FOR NEW BEGINNINGS</span>
      </div>
      <div className="lc-festive-copy">
        <span className="lc-kicker">
          <Sparkles size={16} /> THE FESTIVE EDIT
        </span>
        <h2 id="festive-title">
          A season to celebrate.
          <br />A home to love.
        </h2>
        <div className="lc-discount">
          <strong>
            {festiveOffer.percent}
            <span>%</span>
          </strong>
          <div>
            OFF
            <span>{state === "preview" ? "Proposed festive offer" : "Festive season offer"}</span>
          </div>
        </div>
        <p>Bring your next chapter home. Discover a design direction for the rooms you love.</p>
        <Link to="/offers" className="button">
          <Gift size={17} /> Explore the festive offer
        </Link>
        <small>
          {state === "preview"
            ? "Offer preview. Booking dates, eligible amount and final terms are awaiting confirmation."
            : "Valid on the scope and dates stated in the offer terms."}
        </small>
      </div>
    </section>
  );
}

export function PartnerInvitation() {
  return (
    <section className="wrap lc-section">
      <div className="lc-partner-invite">
        <div>
          <span className="lc-kicker">
            <Handshake size={17} /> THE LUXEINFRA NETWORK
          </span>
          <h2>
            Great spaces start
            <br />
            with great collaborations.
          </h2>
          <p>
            Designers, architects, property professionals and makers. Bring your expertise, and
            let’s explore what we could create together.
          </p>
          <Link to="/partner-with-us" className="button">
            <Handshake size={17} /> Partner with LuxeInfra
          </Link>
          <span className="lc-partner-invite-note">
            Explore collaborations, referrals and opportunities to join our network.
          </span>
        </div>
        <div className="lc-partner-invite-photo">
          <img
            src={office}
            alt="Home workspace design inspiration with warm wood finishes"
            loading="lazy"
            width="800"
            height="600"
          />
          <span>Good ideas deserve good company.</span>
        </div>
      </div>
    </section>
  );
}
