import type { ClientReview } from "./owner-content";

type ReviewCard = {
  id: string;
  title: string;
  quote: string;
  scope: string;
  byline: string;
  location?: string;
};
const layoutExamples: ReviewCard[] = [
  {
    id: "layout-home",
    title: "A home that feels like us.",
    quote:
      "We wanted a calm, personal home with enough storage for everyday life. The layout and material choices brought our ideas together beautifully.",
    scope: "Whole-home interiors",
    byline: "Sample homeowner story",
  },
  {
    id: "layout-kitchen",
    title: "The little details matter.",
    quote:
      "A practical layout and thoughtful storage were our priorities. Having a place for everything made the kitchen feel easier to use every day.",
    scope: "Kitchen & storage",
    byline: "Sample kitchen story",
  },
  {
    id: "layout-bedroom",
    title: "A quieter end to the day.",
    quote:
      "We imagined a warm bedroom with softer lighting and less clutter. The design direction gave us a clearer picture of the space we wanted.",
    scope: "Bedroom interiors",
    byline: "Sample bedroom story",
  },
];

export function selectReviewContent(
  reviews: ClientReview[],
  preview = false,
): { mode: "approved" | "sample" | "empty"; cards: ReviewCard[] } {
  const approved = reviews.filter(
    (r) => r.approved && r.publicationConsent && r.name.trim() && r.quote.trim(),
  );
  if (approved.length)
    return {
      mode: "approved",
      cards: approved.map((r) => ({
        id: r.id,
        title: r.scope || "At home with LuxeInfra",
        quote: r.quote,
        scope: r.scope,
        byline: r.name,
        location: r.city,
      })),
    };
  if (preview) return { mode: "sample", cards: layoutExamples };
  return { mode: "empty", cards: [] };
}
