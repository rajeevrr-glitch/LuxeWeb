import { promotionState, type Promotion } from "./promotion";

export const festiveOffer: Promotion = {
  id: "festive-15",
  percent: 15,
  approved: false,
  startsAt: "",
  endsAt: "",
  terms: [],
};

export const campaignPreview = import.meta.env.VITE_CAMPAIGN_PREVIEW === "true";
export function getFestiveState() {
  return promotionState(festiveOffer, campaignPreview);
}
