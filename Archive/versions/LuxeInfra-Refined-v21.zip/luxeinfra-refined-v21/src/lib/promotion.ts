export type Promotion = {
  id: string;
  approved: boolean;
  percent: number;
  startsAt: string;
  endsAt: string;
  terms: string[];
};

// A draft discount must never become a public promise through a production build.
export function promotionState(
  offer: Promotion,
  preview = false,
  now = new Date(),
): "live" | "preview" | "unavailable" {
  const start = Date.parse(offer.startsAt);
  const end = Date.parse(offer.endsAt);
  const complete =
    offer.approved &&
    Number.isFinite(start) &&
    Number.isFinite(end) &&
    end > start &&
    offer.percent > 0 &&
    offer.percent <= 100 &&
    offer.terms.length > 0 &&
    offer.terms.every((term) => term.trim().length > 0);
  if (complete && now.getTime() >= start && now.getTime() < end) return "live";
  return preview ? "preview" : "unavailable";
}
