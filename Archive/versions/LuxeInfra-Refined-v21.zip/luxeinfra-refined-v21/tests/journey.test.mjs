import { test } from "node:test";
import assert from "node:assert/strict";
import { pricingIsReady, planningJourney, quoteScope } from "../src/lib/journey.ts";
import { welcomeIsTimely } from "../src/lib/welcome.ts";

test("pricing invitation requires approval, valid dates, rate entries and tax information", () => {
  const now = new Date("2026-10-22T12:00:00Z");
  const book = {
    approved: true,
    validUntil: "2026-10-23",
    rates: [{}],
    taxNote: "Taxes specified",
    version: "test",
  };
  assert.equal(pricingIsReady(book, now), true);
  for (const change of [
    { approved: false },
    { rates: [] },
    { validUntil: "2026-10-21" },
    { validUntil: "" },
    { taxNote: " " },
  ])
    assert.equal(pricingIsReady({ ...book, ...change }, now), false);
  assert.equal(pricingIsReady(), false);
  assert.equal(planningJourney().label, "Plan my interiors");
});

test("known quote context avoids repeating the chooser while invalid scope cannot skip it", () => {
  assert.equal(quoteScope({ module: "Kitchen", room: "Kitchen" }), "Kitchen");
  assert.equal(quoteScope({ module: "Wardrobes", room: "Master bedroom" }), "Wardrobes");
  assert.equal(quoteScope({ room: "Master bedroom" }), "Selected rooms");
  assert.equal(quoteScope({ scope: "Whole home" }), "Whole home");
  assert.equal(quoteScope({ scope: "Modular interiors" }), "Kitchen & wardrobes");
  assert.equal(quoteScope({ scope: "random", module: "random" }), "");
});

test("arrival invitation waits for exploration or a longer visit, while explicit preview remains available", () => {
  assert.equal(welcomeIsTimely(11999, true), false);
  assert.equal(welcomeIsTimely(12000, true), true);
  assert.equal(welcomeIsTimely(12000, false), false);
  assert.equal(welcomeIsTimely(29999, false), false);
  assert.equal(welcomeIsTimely(30000, false), true);
  assert.equal(welcomeIsTimely(0, false, true), true);
});
