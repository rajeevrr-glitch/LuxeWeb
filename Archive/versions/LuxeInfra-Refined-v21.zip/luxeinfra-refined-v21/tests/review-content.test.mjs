import { test } from "node:test";
import assert from "node:assert/strict";
import { selectReviewContent } from "../src/lib/review-content.ts";

test("example reviews are available only when content preview is explicitly enabled", () => {
  assert.deepEqual(selectReviewContent([]), { mode: "empty", cards: [] });
  const preview = selectReviewContent([], true);
  assert.equal(preview.mode, "sample");
  assert.equal(preview.cards.length, 3);
  assert.ok(preview.cards.every((card) => card.byline.startsWith("Sample")));
});
test("only approved, permissioned reviews appear as client stories, ahead of layout samples", () => {
  const review = {
    id: "test-review",
    approved: true,
    publicationConsent: true,
    name: "Test client",
    quote: "A verified test fixture",
    city: "Noida",
    scope: "Kitchen",
  };
  assert.equal(selectReviewContent([{ ...review, approved: false }]).mode, "empty");
  assert.equal(selectReviewContent([{ ...review, publicationConsent: false }]).mode, "empty");
  assert.equal(selectReviewContent([{ ...review, name: " " }]).mode, "empty");
  const selected = selectReviewContent([review], true);
  assert.equal(selected.mode, "approved");
  assert.equal(selected.cards[0].byline, "Test client");
  assert.equal(selected.cards.length, 1);
});
