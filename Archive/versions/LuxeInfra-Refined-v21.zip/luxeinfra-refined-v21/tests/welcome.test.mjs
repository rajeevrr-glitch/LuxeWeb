import { test } from "node:test";
import assert from "node:assert/strict";
import {
  welcomeIsEligible,
  welcomeShouldOpen,
  welcomeStorageKey,
  createWelcomeTracker,
} from "../src/lib/welcome.ts";

test("manual open or dismissal cancels a pending invitation even in an explicit preview", () => {
  assert.equal(welcomeShouldOpen("/", false, false), true);
  assert.equal(welcomeShouldOpen("/", true, false), false);
  assert.equal(welcomeShouldOpen("/", true, false, true), true);
  assert.equal(welcomeShouldOpen("/", false, true), false);
  assert.equal(welcomeShouldOpen("/", true, true, true), false);
  assert.equal(welcomeShouldOpen("/callback", false, false, true), false);
});

test("welcome invites marketing visitors without interrupting active forms or privacy", () => {
  for (const path of [
    "/",
    "/about",
    "/design-ideas",
    "/design-ideas/kitchen",
    "/materials",
    "/testimonials",
    "/offers",
  ])
    assert.equal(welcomeIsEligible(path), true, path);
  for (const path of [
    "/estimate",
    "/estimate/",
    "/callback",
    "/plan",
    "/reimagine",
    "/project-brief",
    "/partner-with-us",
    "/privacy",
    "/contact",
    "/find-your-style",
  ])
    assert.equal(welcomeIsEligible(path), false, path);
});
test("welcome session suppression stores only a seen flag and survives route remounts", () => {
  const values = new Map();
  const storage = {
    getItem: (key) => values.get(key) || null,
    setItem: (key, value) => values.set(key, value),
  };
  const first = createWelcomeTracker(storage);
  assert.equal(first.hasSeen(), false);
  first.markSeen();
  assert.equal(first.hasSeen(), true);
  assert.deepEqual([...values], [[welcomeStorageKey, "seen"]]);
  assert.equal(createWelcomeTracker(storage).hasSeen(), true);
  assert.equal(createWelcomeTracker().hasSeen(), false);
});
test("blocked storage still suppresses repeat invitations in the current page runtime", () => {
  const tracker = createWelcomeTracker({
    getItem() {
      throw Error("blocked");
    },
    setItem() {
      throw Error("blocked");
    },
  });
  assert.equal(tracker.hasSeen(), false);
  tracker.markSeen();
  assert.equal(tracker.hasSeen(), true);
});
