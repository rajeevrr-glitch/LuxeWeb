import { spawn } from "node:child_process";
const children = [
  spawn(process.execPath, ["scripts/visualiser-server.mjs"], { stdio: "inherit" }),
  spawn(process.execPath, ["scripts/enquiry-server.mjs"], { stdio: "inherit" }),
  spawn(process.execPath, ["node_modules/vite/bin/vite.js"], { stdio: "inherit" }),
];
let stopping = false;
function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  children.forEach((child) => child.kill());
  process.exitCode = code;
}
children.forEach((child) => child.on("exit", (code) => stop(code || 0)));
process.on("SIGINT", () => stop());
process.on("SIGTERM", () => stop());
