import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { business } from "@/lib/business";
export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "Your project. Your information. — LuxeInfra" }] }),
  component: Page,
});
function Page() {
  return (
    <PageShell>
      <section className="wrap section">
        <div className="page-intro">
          <span className="eyebrow">LUXEINFRA / PRIVACY</span>
          <h1>Your project. Your information.</h1>
        </div>
        <div className="reading-copy">
          <p>This notice explains how this website handles your project information.</p>
          <h2>You choose when to contact us</h2>
          <p>
            The short enquiry form and budget planner prepare your name, phone number, city, broad
            scope and any optional email or preferred call window. Continuing from the short quote
            form opens WhatsApp directly with these details in a draft. You still need to press Send
            in WhatsApp. An email draft is available as a fallback. Nothing is submitted to a
            website enquiry service, and this website cannot confirm message delivery. Continuing
            passes the draft details to WhatsApp through its link before you press Send; LuxeInfra
            receives the chat message only when you send it. The website does not save your contact
            details to browser storage.
          </p>
          <p>
            The budget planner saves your location, scope, approximate sizes and finish preferences
            in this browser tab’s session storage. These choices can carry into your enquiry when
            you choose to discuss your selection. Names, phone numbers, email addresses and
            preferred call windows are held only in the current page, not in browser storage. You
            can edit your choices before sending. Closing the tab ends this session; clearing
            website data also removes saved choices.
          </p>
          <h2>Partnership and career introductions</h2>
          <p>
            The partnership form prepares your interest, name, phone number, city and any optional
            organisation or introduction you add. Continuing opens a WhatsApp draft for you to
            review and send yourself. Email remains available as a fallback. These details are not
            saved to browser storage or submitted to a website enquiry service. LuxeInfra uses the
            details you send to review and respond to your introduction.
          </p>
          <h2>The optional detailed brief</h2>
          <p>
            The planner brings together your room choices, city, contact details, notes and
            inspiration references. Continuing opens WhatsApp with your brief or a shorter
            introduction for long briefs. Press Send there to contact LuxeInfra. The full brief can
            also be downloaded in your browser.
          </p>
          <p>
            WhatsApp opens a message for you to review and send. Email opens a draft addressed to
            sales@luxeinfra.in, with infoluxeinfra@gmail.com copied. Download and attach your
            complete brief and any plans or photos yourself. These external services process
            information under their own policies. LuxeInfra uses the details you send to discuss and
            respond to your project enquiry.
          </p>
          <h2>Choices saved in your browser</h2>
          <p>
            The welcome invitation keeps a simple seen flag in this tab’s session storage so it does
            not keep interrupting your visit. This flag contains no contact details. Closing the
            welcome form clears its personal contact fields. You can use Get a quote to start again;
            the header quote button reopens the invitation on browsing pages.
          </p>
          <p>
            Room, work, style, and other non-contact preferences, along with saved inspiration
            ideas, are kept in your browser so you can return to them. Contact details and uploads
            are not saved in browser storage. Clearing this website’s browser data removes your
            saved preferences.
          </p>
          <h2>Room photos and image generation</h2>
          <p>
            Selected photos stay in the current tab while you prepare your room brief. They are not
            uploaded through the project planner. Leaving or refreshing the page may lose your
            unfinished brief. The public release does not enable AI generation; no photo is sent to
            an AI provider.
          </p>
          <h2>Website delivery</h2>
          <p>
            Your browser requests website files and fonts from the hosting and font services. Those
            services receive connection information such as your IP address. This website does not
            add advertising trackers or visitor analytics.
          </p>
          <h2>Questions or deletion requests</h2>
          <p>
            Contact <a href={"mailto:" + business.email}>{business.email}</a> about your project
            information, corrections or deletion requests. Contact details and files sent to the
            studio remain in the receiving WhatsApp or email service until managed there.
          </p>
        </div>
      </section>
    </PageShell>
  );
}
