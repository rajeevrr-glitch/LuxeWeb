# Release verification — launch cleanup version 15

22 October 2026. Local launch preparation; no public deployment.

Passed:
- All 28 automated tests, including public error disclosure, malformed paths and sitemap coverage; existing pricing, room-work, intake/desk and AI pilot tests still pass.
- Strict unused-local/parameter type checking; lint with zero warnings across source/scripts/tests/config; consistent-format check.
- Public and review builds; 18 rendered route/query combinations and 82 asset references in each. Canonical URLs (including normalized collection paths), social-image metadata, approved-review empty state, campaign gate, career deep link and missing-page 404 checked.
- Refreshed running server: 17 pages and 82 assets returned 200; all 22 sitemap URLs returned 200. Missing page 404, malformed encoded path 400, private environment/source/data paths blocked, staging noindex, public AI off and automatic enquiry POST 405.
- Final npm audit on 22 October: zero known vulnerabilities; manifest and lockfile match. Package inventory reduced from 506 to 397 after unused dependencies were removed.

Limits:
- No new final mobile or full browser interaction sign-off was completed in this cleanup. Prior desktop observations remain documented below. Final mobile/browser verification remains a launch gate.
- No genuine WhatsApp/email message was sent; receipt is still an owner test. Docker, public hosting, HTTPS/DNS routing, monitoring and rollback have not been verified on a selected host.
- Image rights, approved content and actual commercial terms remain owner inputs. Numeric prices, public AI, unapproved offers and automatic receipt/delivery remain inactive.
- See LAUNCH-CHECKLIST.md for launch gates and BLUEPRINT-STATUS-V15.md for the complete 38-feature status register. No independent accessibility/security certification, speed score or load-test result is claimed.

## Earlier version 14 verification
# Release verification — version 14

22 October 2026. Local festive/partnership UI update; no public deployment.

Passed:
- All 26 automated checks, including new draft/approved/expiry boundaries for promotions and validation/message generation for partnership introductions.
- Normal public build, local review build and TypeScript checking. The normal build hides the unapproved 15% offer; review mode shows it as a preview. Sample testimonials remain excluded in both builds.
- Built-page checks: 18 route/query combinations and 83 built asset references for each mode; one main heading on each page, correct role deep link, callback campaign context, approved-review placeholder and missing-page 404.
- Running-server HTTP checks: 17 pages and 83 assets returned 200; staging noindex is set. Unknown page 404; .env.review is blocked; public AI disabled; automatic enquiry POST rejected with 405; partnership page included in the sitemap.
- Dedicated task-only Chrome: partnership desktop hero, navigation, imagery and top festive banner visually inspected. A screenshot was saved as outputs/redesign-v14/partner-desktop.jpg (or .png, according to the capture format).

Limits:
- Human input was detected during further browser interaction, so input was stopped. Final mobile layout and complete browser interactions for the new forms are not claimed verified. Form validation/message composition and route state are covered by the automated and rendered-page checks above.
- No message was sent to WhatsApp/email. Actual receipt still needs an owner test. There is no automatic submission, receipt, referral tracking or partner portal.
- Offer terms, actual joining benefits, genuine vacancies, pricing/catalogue, authentic project/review content, image rights, commercial terms and hosting approval remain pending. Public AI remains off.

## Earlier version 13 verification

21 October 2026. Local service-led UI redesign; no public deployment.

Passed:
- Final production build and TypeScript checking.
- All 22 automated checks for pricing guards, room-specific work, local enquiry/desk controls, pilot AI restrictions and production endpoint handling. No new tests that merely mirror visual styling were added.
- HTTP verification of 15 pages, including wardrobe-specific and 3 BHK entry URLs; 33 homepage image/style/script asset references returned 200. Gallery/scene/save controls and contextual links are present in the rendered page. Missing-page response is 404; public AI remains disabled.
- Dedicated task-only Chrome window: homepage composition, stronger typography, two-level navigation, companion quote selector and manual room thumbnails inspected. Wardrobe selection changes its quote/budget link and arrives at a wardrobe-only modular summary. A kitchen summary-image mismatch was identified and fixed in the final source/build.

Limits:
- User interaction was detected during subsequent browser actions. Further UI interaction was stopped; a full mobile/browser interaction review of version 13 (including gallery save/expand behavior) is still outstanding. Responsive styling and existing save logic are implemented; source/HTTP checks do not substitute for those remaining visual checks.
- Automatic approval rejected access to an unrelated private Chrome window. A separate local-preview window was opened for the permitted visual checks instead; no unrelated page content was read.
- The captured desktop-preview.jpg in task outputs is an intermediate budget-screen observation before the final summary-image fix, not a final homepage/mobile approval screenshot.
- Existing limits remain: actual rates, image rights, verified projects/reviews, catalogue, commercial terms, hosting and real message receipt. Automatic callback delivery and public AI are not enabled.

## Earlier version 12 verification

21 October 2026. Tested local redesign review build; no public deployment.

Passed on the final build:
- Production build and TypeScript checking.
- All 22 automated checks, including missing/expired/unsupported rates, exact units/specifications, safe measurements and whole-home bundle arithmetic. The server tests use temporary local ports; they were run with local network access after the sandbox denied those socket connections.
- HTTP checks: 20 pages/endpoints and 23 homepage asset references returned 200; unknown route returned 404; public AI status is disabled; public testimonials contain no sample reviews.
- Desktop browser: room navigation opens and Escape closes it; room edit changes its image/copy; modular scope/measurements/finish/result work; choices carry to the short enquiry; materials palette carries forward; invalid typed phone is rejected; valid test input produces correct WhatsApp and email To/CC links. No external messages were sent.
- Existing bedroom planning link enters the gateway and preserves Master bedroom in the selected-room estimate. The optional detailed brief remains a separate working route.
- Mobile viewport 390px: homepage, navigation, materials chapters/palettes and whole-home choices/result work. Measured content client/scroll widths both 375px (no horizontal overflow). Final homepage typography was refined after the first mobile check.
- Fresh-selection reset clears the new estimate choices. Existing saved inspiration is preserved.
- No errors recorded in the final homepage browser console.
- Screenshot evidence: outputs/redesign-v12/home-desktop.jpg, home-mobile.jpg and home-full.jpg in the task workspace. Desktop source package includes the preview images separately.

Limits: real prices, product catalogue, verified project/review content, media rights and commercial terms await owner input. Short enquiries use customer-sent WhatsApp/email; automatic receipt, staff assignment and notification delivery are not activated. Hosting, real inbox/WhatsApp receipt, public AI, Docker and end-to-end domain launch have not been tested. No accessibility certification, independent performance score or load-test result is claimed.

## Earlier version 11 verification

18 October 2026. This is a tested local release candidate, not an internet deployment.

Passed:
- All 17 automated tests after the dependency updates. Covers invalid room work, saved-choice migration, private files, local desk access, AI pilot controls and production endpoint restrictions.
- TypeScript checking after adapting the root error component to the framework's unknown error type.
- Production build using patched TanStack Start 1.168.60, React Router 1.170.41 and Vite 7.3.7. The later root edit changed a TypeScript annotation only, with no runtime output change.
- npm audit fix completed with 0 known vulnerabilities in the resulting dependency tree (18 October 2026).
- Production HTTP checks: 16 public routes/assets returned 200; unknown route returned 404. Includes planner, room studio, gallery/category, services, contact, privacy, sitemap, robots and favicon.
- Public testimonials response contains no example review copy.
- Browser: restored bedroom/bathroom choices, all five planner steps, correct review summary, contact consent, ready-to-send screen and edit flow.
- Downloaded synthetic brief inspected: room-specific work, city, contact and budget fields are correct.
- WhatsApp target and email To/CC verified from link destinations. No external message sent.
- Mobile width 390px: planner and ready screen controls present, no horizontal page overflow (scroll width 375px).

Remaining limits:
- Actual hosting account, domain/HTTPS/redirect setup and external email/WhatsApp receipt are not verified.
- Owner image-publication permissions, authentic testimonials and commercial terms remain pending.
- AI API keys were not activated and no paid provider call was made. Public AI remains disabled.
- Dockerfile is prepared but Docker build was not run here.
- No full accessibility certification or load testing has been performed.

