import { Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Calculator,
  Check,
  CheckCircle2,
  ChevronDown,
  Layers3,
  LayoutGrid,
  MessageCircle,
  Palette,
  Phone,
  Plus,
  Ruler,
  Sofa,
  Sparkles,
} from "lucide-react";
import { PageShell } from "./PageShell";
import { ClientStories } from "./ClientStories";
import { SaveInspiration } from "./SaveInspiration";
import { FestiveFeature, PartnerInvitation } from "./Campaigns";
import { business, faqs } from "@/lib/business";
import { spaces, designsFor } from "@/lib/spaces";
import hero from "@/assets/hero-living.jpg";
import kitchen from "@/assets/ideas/kitchen/01.jpg";
import home from "@/assets/full-home.jpg";
import wardrobe from "@/assets/ideas/wardrobe/02.jpg";
import bedroom from "@/assets/ideas/bedroom/02.jpg";
import living from "@/assets/ideas/living/02.jpg";

const heroRooms = [
  {
    label: "Living, beautifully",
    image: hero,
    alt: "Warm living room with ivory seating, wood panelling and a large window",
  },
  { label: "Kitchens, thoughtfully", image: kitchen, alt: "Kitchen interior design inspiration" },
  { label: "Bedrooms, personally", image: bedroom, alt: "Bedroom interior design inspiration" },
];
const solutionCards = [
  {
    title: "Complete home interiors",
    tag: "THE BIG PICTURE",
    image: home,
    slug: "full-home",
    text: "A connected design for your kitchen, bedrooms, living spaces and all the details in between.",
    chips: ["Layouts", "Materials", "Room-by-room planning"],
  },
  {
    title: "Modular kitchens",
    tag: "MADE FOR YOUR EVERYDAY",
    image: kitchen,
    slug: "kitchen",
    text: "Make cooking, storage and movement feel effortless, with a layout that works around you.",
    chips: ["Cabinetry", "Storage", "Finishes"],
  },
  {
    title: "Wardrobes & storage",
    tag: "A PLACE FOR EVERYTHING",
    image: wardrobe,
    slug: "wardrobe",
    text: "Considered storage, from the way the doors open to the things you keep inside.",
    chips: ["Internal planning", "Hardware", "Personal style"],
  },
];
const galleryRooms = [
  { slug: "kitchen", title: "Kitchens" },
  { slug: "living", title: "Living rooms" },
  { slug: "bedroom", title: "Bedrooms" },
  { slug: "wardrobe", title: "Wardrobes" },
  { slug: "kids", title: "Kids’ rooms" },
  { slug: "pooja", title: "Pooja spaces" },
];
const shortcuts = [
  "full-home",
  "kitchen",
  "wardrobe",
  "bedroom",
  "living",
  "kids",
  "pooja",
  "office",
];

export function StudioHome() {
  const [heroIndex, setHeroIndex] = useState(0);
  const [interest, setInterest] = useState("Whole home");
  const [room, setRoom] = useState("kitchen");
  const [expanded, setExpanded] = useState(false);
  const allDesigns = designsFor(room);
  const designs = allDesigns.slice(0, expanded ? 6 : 3);
  const activeRoom = galleryRooms.find((item) => item.slug === room)!;
  const scope = interest === "Whole home" ? "Whole home" : "Modular interiors";
  const module =
    interest === "Kitchen" ? "Kitchen" : interest === "Wardrobes" ? "Wardrobes" : undefined;
  return (
    <PageShell>
      <section className="lc-hero wrap" aria-labelledby="home-title">
        <div className="lc-hero-scene">
          <img
            src={heroRooms[heroIndex].image}
            alt={heroRooms[heroIndex].alt}
            className="lc-hero-photo"
            width="1920"
            height="1080"
            fetchPriority="high"
          />
          <div className="lc-hero-overlay" />
          <span className="lc-photo-label">
            <span />
            {heroRooms[heroIndex].label}
          </span>
          <div className="lc-hero-copy">
            <span className="lc-overline">LUXEINFRA HOME INTERIORS</span>
            <h1 id="home-title">
              Your home.
              <br />
              Your style.
              <br />
              <span>Beautifully together.</span>
            </h1>
            <p>
              From your first kitchen to a complete home.
              <br />
              Let’s design a space that feels like you.
            </p>
            <Link to="/design-ideas" className="button light">
              Explore design ideas
            </Link>
          </div>
          <div className="lc-scene-switch" role="group" aria-label="Choose hero room">
            {heroRooms.map((item, i) => (
              <button
                key={item.label}
                aria-label={"Show " + item.label}
                aria-pressed={i === heroIndex}
                onClick={() => setHeroIndex(i)}
              >
                <img src={item.image} alt="" />
                <span>{["Living", "Kitchen", "Bedroom"][i]}</span>
              </button>
            ))}
          </div>
          <span className="lc-image-note">Design inspiration</span>
        </div>
        <div className="lc-hero-start">
          <span className="lc-kicker">
            <Sparkles size={15} /> YOUR HOME STARTS HERE
          </span>
          <h2>
            Great interiors.
            <br />A simple beginning.
          </h2>
          <p>What would you like to design?</p>
          <div className="lc-interest" role="group" aria-label="Choose your project">
            {[
              ["Whole home", home],
              ["Kitchen", kitchen],
              ["Wardrobes", wardrobe],
            ].map(([label, image]) => (
              <button
                key={label}
                aria-pressed={interest === label}
                onClick={() => setInterest(label)}
              >
                <img src={image} alt="" />
                <span>{label}</span>
                <span className="lc-radio">{interest === label && <Check size={12} />}</span>
              </button>
            ))}
          </div>
          <Link
            to="/callback"
            search={{ scope, module, room: interest === "Kitchen" ? "Kitchen" : undefined }}
            className="button lc-quote"
          >
            <Phone size={16} />
            Get a personalised quote
          </Link>
          <Link to="/estimate" search={{ scope, module }} className="lc-budget-link">
            <Calculator size={17} />
            Explore my budget
          </Link>
          <span className="lc-hero-small">
            Start with a conversation. No detailed brief needed.
          </span>
        </div>
      </section>
      <section className="wrap lc-room-shortcuts" aria-label="Browse rooms">
        {shortcuts.map((slug) => {
          const item = spaces.find((s) => s.slug === slug)!;
          return (
            <Link to="/design-ideas/$category" params={{ category: slug }} key={slug}>
              <img src={item.image} alt="" width="100" height="80" />
              <span>
                {slug === "full-home"
                  ? "Full home"
                  : slug === "office"
                    ? "Home office"
                    : slug === "kids"
                      ? "Kids’ rooms"
                      : slug === "pooja"
                        ? "Pooja spaces"
                        : item.title.replace(" & storage", "")}
              </span>
            </Link>
          );
        })}
      </section>
      <div className="lc-benefit-strip">
        <div className="wrap">
          {[
            { Icon: Sofa, title: "Designed around you", text: "Your rooms. Your routines." },
            {
              Icon: Layers3,
              title: "Clarity in the details",
              text: "Discuss materials and scope.",
            },
            {
              Icon: LayoutGrid,
              title: "A room or a whole home",
              text: "Start with what you need.",
            },
            {
              Icon: MessageCircle,
              title: "A simpler first step",
              text: "Talk directly to our studio.",
            },
          ].map(({ Icon, title, text }) => {
            return (
              <div key={title}>
                <Icon size={25} strokeWidth={1.6} />
                <span>
                  <strong>{title}</strong>
                  <small>{text}</small>
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <section className="wrap lc-section" aria-labelledby="solutions-title">
        <div className="lc-section-head">
          <div>
            <span className="lc-kicker">DESIGNED FOR THE WAY YOU LIVE</span>
            <h2 id="solutions-title">One home. So many possibilities.</h2>
            <p>Choose the space. We’ll help bring the possibilities together.</p>
          </div>
          <Link to="/services" className="lc-text-action">
            Explore our services
          </Link>
        </div>
        <div className="lc-solutions">
          {solutionCards.map((item) => (
            <article key={item.slug}>
              <Link
                to="/design-ideas/$category"
                params={{ category: item.slug }}
                className="lc-solution-photo"
              >
                <img
                  src={item.image}
                  alt={item.title + " inspiration"}
                  loading="lazy"
                  width="600"
                  height="400"
                />
                <span>{item.tag}</span>
              </Link>
              <div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
                <div className="lc-tags">
                  {item.chips.map((chip) => (
                    <span key={chip}>{chip}</span>
                  ))}
                </div>
                <Link
                  to="/design-ideas/$category"
                  params={{ category: item.slug }}
                  className="lc-text-action"
                >
                  Explore designs
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <FestiveFeature />
      <section className="lc-gallery-section">
        <div className="wrap lc-section">
          <div className="lc-section-head">
            <div>
              <span className="lc-kicker">THE DESIGN GALLERY</span>
              <h2>Find a look you’d love to come home to.</h2>
              <p>Explore, save and bring your favourite ideas into the conversation.</p>
            </div>
            <Link to="/my-inspiration" className="lc-text-action">
              My saved ideas
            </Link>
          </div>
          <div className="lc-gallery-tabs" role="group" aria-label="Filter design inspiration">
            {galleryRooms.map((item) => (
              <button
                key={item.slug}
                aria-pressed={room === item.slug}
                onClick={() => {
                  setRoom(item.slug);
                  setExpanded(false);
                }}
              >
                {item.title}
              </button>
            ))}
          </div>
          <div className="lc-design-grid">
            {designs.map((design, i) => (
              <article key={design.id}>
                <div className="lc-design-photo">
                  <Link
                    to="/design-ideas/$category"
                    params={{ category: room }}
                    hash={design.id}
                    aria-label={"Explore " + design.title}
                  >
                    <img
                      src={design.image}
                      alt={design.title + " design inspiration"}
                      loading="lazy"
                      width="600"
                      height="450"
                    />
                  </Link>
                  <SaveInspiration item={design} compact />
                </div>
                <div className="lc-design-info">
                  <span>{activeRoom.title}</span>
                  <h3>Design {String(i + 1).padStart(2, "0")}</h3>
                  <Link to="/design-ideas/$category" params={{ category: room }} hash={design.id}>
                    View collection
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className="lc-gallery-bottom">
            <span>Illustrative design references, not completed LuxeInfra projects.</span>
            <button
              type="button"
              className="button secondary"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? "Show fewer designs" : "More " + activeRoom.title.toLowerCase()}
              <ChevronDown size={15} className={expanded ? "lc-rotated" : ""} />
            </button>
          </div>
        </div>
      </section>

      <section className="wrap lc-section">
        <div className="lc-cost-banner">
          <div>
            <span className="lc-kicker">PLAN YOUR SPACE. UNDERSTAND YOUR SCOPE.</span>
            <h2>
              A beautiful home starts
              <br />
              with a clearer budget.
            </h2>
            <p>
              Explore the work, sizes and finish direction you have in mind. Start without sharing
              your phone number.
            </p>
            <span className="lc-cost-note">
              <CheckCircle2 size={15} />
              No contact details needed to explore
            </span>
          </div>
          <div className="lc-calculators">
            {[
              { name: "Full home", image: home, scope: "Whole home", module: undefined },
              { name: "Kitchen", image: kitchen, scope: "Modular interiors", module: "Kitchen" },
              {
                name: "Wardrobes",
                image: wardrobe,
                scope: "Modular interiors",
                module: "Wardrobes",
              },
            ].map((item) => (
              <Link
                to="/estimate"
                search={{ scope: item.scope, module: item.module }}
                key={item.name}
              >
                <img src={item.image} alt="" loading="lazy" />
                <Calculator size={22} />
                <strong>{item.name}</strong>
                <span>Explore budget</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="wrap lc-section lc-home-plans">
        <div className="lc-section-head">
          <div>
            <span className="lc-kicker">YOUR HOME, YOUR STARTING POINT</span>
            <h2>Interiors that fit your kind of home.</h2>
            <p>Bring your rooms together with a coordinated design direction.</p>
          </div>
        </div>
        <div className="lc-home-grid">
          {[
            { name: "2 BHK", image: living, tag: "A thoughtful place to begin" },
            { name: "3 BHK", image: home, tag: "More room for everyday life" },
            { name: "4+ BHK", image: hero, tag: "A bigger vision, brought together" },
          ].map((item) => (
            <article key={item.name}>
              <img src={item.image} alt={item.name + " home interior inspiration"} loading="lazy" />
              <div>
                <span className="lc-kicker">{item.tag}</span>
                <h3>{item.name} home interiors</h3>
                <p>Explore your scope, priorities and finish preferences.</p>
                <Link
                  to="/estimate"
                  search={{ scope: "Whole home", configuration: item.name }}
                  className="button secondary"
                >
                  Plan my {item.name} home
                </Link>
              </div>
            </article>
          ))}
        </div>
        <p className="lc-fine-print">
          These are planning starting points. Rooms, quantities, materials and inclusions are agreed
          for your project.
        </p>
      </section>

      <section className="lc-choice-section">
        <div className="wrap lc-section">
          <div className="lc-section-head">
            <div>
              <span className="lc-kicker">THOUGHTFUL FROM THE START</span>
              <h2>More than a good-looking space.</h2>
              <p>The decisions behind your interiors matter just as much.</p>
            </div>
          </div>
          <div className="lc-why-grid">
            {[
              {
                Icon: Palette,
                title: "Your taste comes first",
                text: "Save what you love and explore your style. Bring a personal starting point to the design conversation.",
              },
              {
                Icon: Layers3,
                title: "Know what you’re choosing",
                text: "Discuss the boards, surfaces, hardware and exclusions behind your quotation.",
              },
              {
                Icon: Ruler,
                title: "Start with your priorities",
                text: "A kitchen, better storage or a whole-home plan. Begin with the work that matters to you.",
              },
              {
                Icon: MessageCircle,
                title: "Keep the first step simple",
                text: "Share a short enquiry on WhatsApp or email. Go into the detail when you talk to the studio.",
              },
            ].map(({ Icon, title, text }) => (
              <article key={title}>
                <span>
                  <Icon size={27} strokeWidth={1.6} />
                </span>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="wrap lc-section lc-discovery-grid">
        <article className="lc-style-promo">
          <img src={bedroom} alt="Bedroom style inspiration" loading="lazy" />
          <div>
            <span className="lc-overline">FIND YOUR DESIGN PERSONALITY</span>
            <h2>
              Not sure what
              <br />
              your style is?
              <br />
              <em>Start with what you love.</em>
            </h2>
            <Link to="/find-your-style" className="button light">
              <Palette size={17} />
              Discover my style
            </Link>
          </div>
        </article>
        <article className="lc-room-promo">
          <div className="lc-room-promo-image">
            <img src={living} alt="Living room design inspiration" loading="lazy" />
            <span>
              <Ruler size={15} /> YOUR ROOM, YOUR POSSIBILITIES
            </span>
          </div>
          <div>
            <span className="lc-kicker">THE ROOM STUDIO</span>
            <h2>Have a room in mind?</h2>
            <p>
              Add a photo, dimensions and what you’d like to change. Bring your ideas together
              before you talk to us.
            </p>
            <Link to="/reimagine" className="button">
              <Sparkles size={17} />
              Plan my room
            </Link>
          </div>
        </article>
      </section>

      <section className="wrap lc-section lc-material-promo">
        <div className="lc-material-photo">
          <img
            src={wardrobe}
            alt="Wardrobe surfaces and storage design inspiration"
            loading="lazy"
          />
          <div className="lc-material-samples" aria-label="Illustrative palette">
            <span className="lx-oak" />
            <span className="lx-stone" />
            <span className="lx-ivory-swatch" />
            <span className="lx-blue" />
          </div>
        </div>
        <div>
          <span className="lc-kicker">THE DETAILS MAKE THE DIFFERENCE</span>
          <h2>
            Beautiful on the outside.
            <br />
            Considered on the inside.
          </h2>
          <p>
            Get to know your materials before choosing a finish. Ask better questions about
            construction, surfaces and the details you use every day.
          </p>
          <ul>
            <li>
              <Check size={16} />
              Boards & construction
            </li>
            <li>
              <Check size={16} />
              Surfaces & colour
            </li>
            <li>
              <Check size={16} />
              Hardware & internal fittings
            </li>
          </ul>
          <Link to="/materials" className="button secondary">
            Explore the materials guide
          </Link>
          <small>
            Illustrative palettes. Final selections require physical samples and agreed
            specifications.
          </small>
        </div>
      </section>

      <section className="lc-process">
        <div className="wrap lc-section">
          <div className="lc-section-head">
            <div>
              <span className="lc-kicker">FROM IDEAS TO YOUR EVERYDAY</span>
              <h2>Your home journey, made clearer.</h2>
            </div>
            <Link to="/how-it-works" className="lc-text-action">
              How it works
            </Link>
          </div>
          <div className="lc-steps">
            {[
              ["01", "Let’s talk", "Your space, your ideas and the work you’re considering."],
              [
                "02",
                "Shape the design",
                "Explore layouts, specifications and your itemised scope.",
              ],
              ["03", "Agree the details", "Confirm the work, approvals and project schedule."],
              [
                "04",
                "Bring it home",
                "Review the finished work, care guidance and applicable support.",
              ],
            ].map(([n, title, text]) => (
              <div key={n}>
                <span>{n}</span>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <ClientStories />
      <PartnerInvitation />
      <section className="wrap lc-section lc-regions">
        <div>
          <span className="lc-kicker">LET’S BRING IT HOME</span>
          <h2>
            Good design,
            <br />
            closer to you.
          </h2>
          <p>Tell us your city or locality so we can confirm arrangements for your space.</p>
        </div>
        <div>
          {business.areas.map((city, i) => (
            <Link to="/callback" search={{ city }} key={city}>
              <span>{String(i + 1).padStart(2, "0")}</span>
              <h3>{city}</h3>
              <small>Discuss my project</small>
            </Link>
          ))}
        </div>
      </section>
      <section className="wrap lc-section lc-faq">
        <div className="lc-section-head">
          <div>
            <span className="lc-kicker">YOUR QUESTIONS, ANSWERED</span>
            <h2>Before we get started.</h2>
          </div>
          <a href={business.phoneHref} className="lc-text-action">
            Speak to the studio
          </a>
        </div>
        <div>
          {faqs.map(([q, a]) => (
            <details key={q}>
              <summary>
                {q}
                <Plus size={17} />
              </summary>
              <p>{a}</p>
            </details>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
