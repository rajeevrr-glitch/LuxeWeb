import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { publishedReviews } from "@/lib/owner-content";
import { ClientStories } from "@/components/ClientStories";

export const Route = createFileRoute("/testimonials")({
  head: () => ({
    meta: [
      { title: "Client stories — LuxeInfra" },
      { name: "robots", content: publishedReviews.length ? "index, follow" : "noindex, follow" },
    ],
  }),
  component: Testimonials,
});
function Testimonials() {
  return (
    <PageShell>
      {publishedReviews.length ? (
        <>
          <section className="wrap lx-page-intro">
            <span className="eyebrow">WORDS FROM HOME</span>
            <h1>
              The personal side
              <br />
              <em>of interiors.</em>
            </h1>
          </section>
          <ClientStories kind="reviews" />
        </>
      ) : (
        <section className="section wrap page-heading">
          <span className="eyebrow">CLIENT STORIES</span>
          <h1>Every home has a story.</h1>
          <p>
            Approved client stories will appear here. In the meantime, explore design ideas for your
            own space.
          </p>
          <Link to="/design-ideas" className="button">
            Explore spaces
          </Link>
        </section>
      )}
    </PageShell>
  );
}
