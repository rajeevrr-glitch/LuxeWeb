# LuxeInfra — launch preparation version 15

Updated 22 October 2026. Start with README.md and LAUNCH-CHECKLIST.md. workdone.md records the complete history. No public deployment has been made.

## Run and review

Requires Node 24 or later. Use npm and the included package-lock.json.

    npm ci
    npm run lint
    npm run typecheck
    npm test
    npm run format:check
    npm run build
    node scripts/verify-redesign.mjs
    npm start

Open http://localhost:3000. The normal build hides unapproved promotions, fake reviews and numerical prices. Short enquiries prepare WhatsApp/email drafts for the visitor to send. Public AI generation remains off.

For the proposed festive-offer design, use `npm run build:review`, `node scripts/verify-redesign.mjs --review`, then `npm start`. The included .env.review has one non-secret preview flag. This mode remains noindex and must not be deployed publicly.

## Hosting settings

Use a Node 24 web-service host with managed HTTPS. This is a server-rendered TanStack Start application, not a static folder for an ordinary shared-hosting file manager.

- Build: `npm ci && npm run build`
- Start: `npm start`
- Health path: `/healthz`
- HOST: `0.0.0.0`
- PORT: supplied by the host; default 3000
- SITE_URL: `https://luxeinfra.in`
- INDEXABLE: `false` on staging; `true` only after approval on the final domain

Canonical/social URLs target https://luxeinfra.in. If the preferred final domain changes, update business.siteUrl in src/lib/business.ts and the host's SITE_URL together before building. The sitemap covers the public page list and room collections. Inactive offers and private/intake pages are excluded.

Dockerfile is provided as another Node hosting option; Docker has not been run on this laptop. The obsolete Worker configuration was removed because this checkout is configured for the included Node server.

## Source and runtime data

The versioned handover excludes .private, real environment files, .npm-cache, node_modules, generated dist output and builder metadata. .env.example and the non-secret .env.review are the only environment templates included. npm ci and npm run build recreate dependencies/build output. Do not publish local pilot servers or the enquiry desk.

No API key, database or mail password is required for the visitor-sent WhatsApp/email launch. Adding a key does not enable public AI. Local AI/desk/intake pilots remain separate, tested development tools; see AI-SETUP.md for their setup and limitations.

## Switch the domain only after the checklist is complete

Deploy to the chosen host's review URL first. Test desktop/mobile behavior and real WhatsApp/email receipt. Confirm image rights and public wording. Back up the current DNS records; change only required website records, preserve mail MX/TXT/DKIM/DMARC records and keep the Lovable version for rollback. Verify apex/www routing and HTTPS, then enable indexing and recheck metadata, robots.txt and sitemap.xml.

No account purchase, domain connection, Lovable edit, push or public deployment was performed by this preparation.
