# LuxeInfra website

Interactive welcome version 18 — 22 October 2026. Read LAUNCH-CHECKLIST.md for remaining decisions and LAUNCH-README.md for deployment instructions. The work history is in workdone.md; current welcome behavior and checks are in QA-REPORT-V18.md. SALES-REVIEW-V17.md explains the underlying sales journeys; prior browser evidence is historical.

## Run locally

Requires Node.js 24 or later. Install dependencies with `npm ci`.

- `npm run dev`: design development on port 5173, with the separate local-only AI/enquiry pilot services.
- `npm run build` then `npm start`: public-mode site on port 3000. Unapproved promotions and numerical prices are inactive.
- `npm run build:review` then `npm start`: local review with the proposed festive offer and clearly labelled sample client stories. Do not deploy this mode publicly.
- `npm run lint`, `npm run typecheck`, `npm test`, `npm run format:check`: quality checks.
- `node scripts/verify-redesign.mjs`: checks a public build; add `--review` after a review build.

Start-release.cmd builds and opens the local public release process; Start-preview.cmd starts development. Keep the terminal running while viewing the site. These commands do not publish it.

## Current visitor journeys

Room inspiration and saved ideas; style discovery; materials guidance; room-specific project planning; short quote enquiries; a budget/scope planner; room-photo briefing; and partnership/career introductions.

The budget journey begins with visual BHK/size choices, then relevant interiors and contact details before the final plan/result. It supports 1 RK through 5+ BHK, simple size bands and optional exact measurements. Quick quotes start with project-choice cards, then contact details and a manual handoff. Optional email/call preferences are held in page memory only. The v17 report records its original browser-testing limit; current v18 welcome checks are listed below and do not imply full coverage of every existing form branch.

V18 adds an animated welcome quote form that opens after 1.8 seconds on eligible browsing pages, once per tab session. Choosing a project changes the photo/copy and reveals optional BHK choices for a whole home. Contact fields and a manual WhatsApp/email handoff follow. Close/Escape, an exploring option and a floating reopen button are available. It waits around open menus/dialogs/typing and does not auto-open on quote, budget, brief, room-studio, partner, privacy, contact or style-quiz journeys. Personal fields clear on close; only a non-personal seen flag is stored. `/?welcome=1` explicitly previews the invitation even in a previously seen session. Narrow-viewport browser checks are recorded in QA-REPORT-V18.md; full desktop/device coverage is not implied.

Short enquiries prepare WhatsApp/email drafts. The visitor reviews and sends them. Files must be attached in the selected app. The website does not automatically send messages, upload customer files or confirm receipt.

Numerical estimates need approved rates. Festive offers need approved dates and terms. The homepage and permanent Reviews navigation now show a client-stories section even before genuine reviews are supplied. The normal public build uses only approved, permissioned reviews, or an invitation to share an experience. Local review mode alone shows labelled layout examples. Public AI generation is disabled.

## Code and notes

- `src/routes`: page journeys; `src/components`: shared interface; `src/lib`: business details, room logic, pricing and publication controls.
- `src/styles.css`, `studio.css`, `refinement.css`, `launch.css`, `commerce.css`, `campaigns.css`, `reviews.css`, `sales.css`, `welcome.css`: ordered style layers for the retained theme, reviews, sales journeys and welcome invitation.
- `scripts/production-server.mjs`: public Node server. Other enquiry/desk/AI scripts are local pilots and are not connected to public intake.
- `tests`: validation, pricing, server, privacy and pilot checks.
- `owner-inputs`: rates, catalogue, genuine content and commercial inputs still needed.
- `workdone.md`: chronological history; REDESIGN-V12/13/14 and earlier handover documents are historical references.

npm and package-lock.json are the dependency source of truth. The unused Bun lockfile, spare UI templates and obsolete Worker configuration have been removed. Keep private runtime data, credentials, caches, dependencies and generated build folders out of source handovers.

## Confirmed contacts

sales@luxeinfra.in, copied to infoluxeinfra@gmail.com. WhatsApp +91 9026271638; second call number +91 7678432743. Service areas: Uttar Pradesh, Delhi NCR and Bengaluru.

No live hosting, Lovable project or GoDaddy DNS was changed by this cleanup.
