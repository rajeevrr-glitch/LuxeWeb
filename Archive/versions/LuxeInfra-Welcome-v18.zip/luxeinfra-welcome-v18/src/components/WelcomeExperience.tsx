import { useEffect, useRef, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Check,
  Sparkles,
  ArrowLeft,
  House,
  CookingPot,
  DoorOpen,
  BedDouble,
  MessageCircle,
  Palette,
} from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { ContactFields, ContactDisclosure, EnquiryHandoff } from "@/components/EnquiryContact";
import { emptyContact, validateLead, leadMessage, type LeadContact } from "@/lib/sales-funnel";
import { homeConfigurations } from "@/lib/estimate";
import { createWelcomeTracker, welcomeIsEligible, welcomeShouldOpen } from "@/lib/welcome";
import living from "@/assets/hero-living.jpg";
import kitchen from "@/assets/kitchen.jpg";
import wardrobe from "@/assets/wardrobe.jpg";
import bedroom from "@/assets/bedroom.jpg";

const tracker = createWelcomeTracker({
  getItem: (key) => window.sessionStorage.getItem(key),
  setItem: (key, value) => window.sessionStorage.setItem(key, value),
});
const projects = [
  {
    id: "home",
    title: "My whole home",
    short: "Whole home",
    scope: "Whole home",
    image: living,
    Icon: House,
    line: ["A place for your", "next chapter."],
    detail: "Thoughtful spaces. Beautifully together.",
  },
  {
    id: "kitchen",
    title: "A better kitchen",
    short: "Kitchen",
    scope: "Modular interiors",
    image: kitchen,
    Icon: CookingPot,
    line: ["Good mornings.", "Better kitchens."],
    detail: "Made for the way you cook, gather and live.",
  },
  {
    id: "wardrobes",
    title: "Smarter wardrobes",
    short: "Wardrobes",
    scope: "Modular interiors",
    image: wardrobe,
    Icon: DoorOpen,
    line: ["Less clutter.", "More possibility."],
    detail: "Storage with a place for everything.",
  },
  {
    id: "room",
    title: "A room, reimagined",
    short: "Selected rooms",
    scope: "Selected rooms",
    image: bedroom,
    Icon: BedDouble,
    line: ["Your favourite room.", "A fresh feeling."],
    detail: "Begin with one space. Make it personal.",
  },
] as const;
type ProjectId = (typeof projects)[number]["id"] | "guidance";

export function WelcomeExperience() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [selection, setSelection] = useState<ProjectId | "">("");
  const [configuration, setConfiguration] = useState("");
  const [contact, setContact] = useState<LeadContact>({ ...emptyContact });
  const [error, setError] = useState("");
  const heading = useRef<HTMLHeadingElement>(null);
  const launcher = useRef<HTMLButtonElement>(null);
  const previousPath = useRef(pathname);
  const interacted = useRef(false);
  const eligible = welcomeIsEligible(pathname);
  const project = projects.find((item) => item.id === selection);
  const scene = project || projects[0];

  useEffect(() => {
    if (!eligible) return;
    const forced = new URLSearchParams(window.location.search).get("welcome") === "1";
    if (!welcomeShouldOpen(pathname, tracker.hasSeen(), interacted.current, forced)) return;
    let timer: ReturnType<typeof setTimeout>;
    let cancelled = false;
    function invite() {
      if (cancelled || !welcomeShouldOpen(pathname, tracker.hasSeen(), interacted.current, forced))
        return;
      // Do not cover a menu, image viewer, active text entry or a background tab.
      const active = document.activeElement;
      const busy =
        document.hidden ||
        active?.matches("input, textarea, select, [contenteditable='true']") ||
        document.querySelector(
          '[role="dialog"][data-state="open"], .mobile-nav, [aria-controls="spaces-menu"][aria-expanded="true"]',
        );
      if (busy) {
        timer = setTimeout(invite, 1800);
        return;
      }
      tracker.markSeen();
      setOpen(true);
    }
    timer = setTimeout(invite, 1800);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [pathname, eligible]);

  useEffect(() => {
    if (previousPath.current === pathname) return;
    previousPath.current = pathname;
    setOpen(false);
    setStep(0);
    setContact({ ...emptyContact });
    setError("");
  }, [pathname]);

  function changeOpen(next: boolean) {
    interacted.current = true;
    if (next) tracker.markSeen();
    setOpen(next);
    if (!next) {
      setContact({ ...emptyContact });
      setStep(0);
      setError("");
    }
  }
  function go(next: number) {
    setStep(next);
    setError("");
    requestAnimationFrame(() => {
      heading.current?.focus({ preventScroll: true });
      heading.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }
  function update(key: keyof LeadContact, value: string) {
    setContact((old) => ({ ...old, [key]: value }));
    setError("");
  }
  function prepare(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const invalid = validateLead(contact);
    if (invalid) {
      setError(invalid);
      return;
    }
    go(2);
  }
  if (!eligible) return null;
  const context =
    "Interested in: " +
    (project?.short || "Design guidance") +
    (selection === "home" && configuration ? "\nHome type: " + configuration : "");
  return (
    <>
      <button
        ref={launcher}
        type="button"
        className="lw-launcher"
        aria-label="Open your home quote form"
        aria-haspopup="dialog"
        hidden={open}
        onClick={() => changeOpen(true)}
      >
        <span className="lw-launcher-icon">
          <Sparkles size={19} />
        </span>
        <span>
          <small>A home on your mind?</small>
          <strong>Let’s bring it to life</strong>
        </span>
        <span className="lw-launcher-dot" />
      </button>
      <Dialog open={open} onOpenChange={changeOpen}>
        <DialogContent
          className="luxe-commerce lw-dialog"
          data-step={step}
          onOpenAutoFocus={(event) => {
            event.preventDefault();
            heading.current?.focus();
          }}
          onCloseAutoFocus={(event) => {
            event.preventDefault();
            launcher.current?.focus({ preventScroll: true });
          }}
        >
          <div className="lw-scene">
            <img
              key={scene.id}
              src={scene.image}
              alt={`${scene.short} design inspiration`}
              width="700"
              height="900"
            />
            <div className="lw-brand">
              LUXE<span>INFRA</span>
              <small>INTERIORS, CONSIDERED.</small>
            </div>
            <div className="lw-floating-note">
              <Palette size={18} />
              <span>
                YOUR TASTE.
                <br />
                <strong>YOUR KIND OF HOME.</strong>
              </span>
            </div>
            <div className="lw-scene-copy" key={scene.id + "-copy"}>
              <span>LET’S MAKE IT YOURS</span>
              <p>
                {scene.line[0]}
                <br />
                <em>{scene.line[1]}</em>
              </p>
              <small>{scene.detail}</small>
            </div>
            <span className="lw-reference">DESIGN INSPIRATION</span>
          </div>
          <div className="lw-content">
            <div
              className="lw-progress"
              aria-label={`Quote request step ${Math.min(step + 1, 3)} of 3`}
            >
              {["Your space", "Your details", "Share request"].map((label, i) => (
                <span
                  key={label}
                  aria-current={i === step ? "step" : undefined}
                  data-complete={step > i}
                >
                  <b>{step > i ? <Check size={10} /> : i + 1}</b>
                  {label}
                </span>
              ))}
            </div>
            <div className="lw-step" key={step}>
              <span className="lw-kicker">
                <Sparkles size={13} /> A LITTLE INSPIRATION. A BEAUTIFUL BEGINNING.
              </span>
              <DialogTitle ref={heading} tabIndex={-1} className="lw-title">
                {step === 0 ? (
                  <>
                    Your home story
                    <br />
                    starts with <em>you.</em>
                  </>
                ) : step === 1 ? (
                  <>
                    Let’s put a name
                    <br />
                    to your <em>vision.</em>
                  </>
                ) : (
                  <>
                    One step closer
                    <br />
                    to <em>your home.</em>
                  </>
                )}
              </DialogTitle>
              <DialogDescription className="lw-description">
                {step === 0
                  ? "What would you love to create?"
                  : step === 1
                    ? "A few essentials for a personal conversation. Your choice is already included."
                    : "Your choices are ready. Share them with the studio when you’re ready."}
              </DialogDescription>
              {step === 0 && (
                <>
                  <div className="lw-projects" role="group" aria-label="Choose your project">
                    {projects.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        aria-pressed={selection === item.id}
                        onClick={() => {
                          setSelection(item.id);
                          setConfiguration("");
                          setError("");
                        }}
                      >
                        <img src={item.image} alt="" width="80" height="80" />
                        <span>
                          <item.Icon size={16} />
                          <strong>{item.title}</strong>
                        </span>
                        <Check size={12} className="lw-project-tick" />
                      </button>
                    ))}
                  </div>
                  {selection === "home" && (
                    <fieldset className="lw-home-types">
                      <legend>
                        Your home type <span>Optional</span>
                      </legend>
                      <div>
                        {homeConfigurations.map((config) => (
                          <button
                            type="button"
                            key={config}
                            aria-pressed={configuration === config}
                            onClick={() => setConfiguration(config)}
                          >
                            {config}
                          </button>
                        ))}
                      </div>
                    </fieldset>
                  )}
                  <button
                    type="button"
                    className="lw-guidance"
                    aria-pressed={selection === "guidance"}
                    onClick={() => {
                      setSelection("guidance");
                      setConfiguration("");
                      setError("");
                    }}
                  >
                    <Sparkles size={13} /> Not sure yet? Help me find my direction
                    {selection === "guidance" && <Check size={13} />}
                  </button>
                  {error && (
                    <p className="lx-error" role="alert">
                      {error}
                    </p>
                  )}
                  <button
                    type="button"
                    className="button lw-primary"
                    onClick={() => {
                      if (!selection) {
                        setError("Pick a space, or choose Help me find my direction.");
                        return;
                      }
                      go(1);
                    }}
                  >
                    <MessageCircle size={17} />
                    {selection
                      ? "Let’s talk about my " +
                        (selection === "guidance"
                          ? "ideas"
                          : selection === "home"
                            ? "home"
                            : selection === "kitchen"
                              ? "kitchen"
                              : selection === "wardrobes"
                                ? "wardrobes"
                                : "room")
                      : "Let’s bring my ideas to life"}
                  </button>
                  <p className="lw-soft-note">No floor plan needed. Start with what you know.</p>
                  <div className="lw-browse">
                    <button type="button" onClick={() => changeOpen(false)}>
                      I’m just exploring
                    </button>
                    <Link
                      to="/estimate"
                      search={{
                        scope: project?.scope || "Whole home",
                        module:
                          selection === "kitchen"
                            ? "Kitchen"
                            : selection === "wardrobes"
                              ? "Wardrobes"
                              : undefined,
                        configuration:
                          selection === "home" && configuration ? configuration : undefined,
                      }}
                      onClick={() => changeOpen(false)}
                    >
                      Plan my budget instead
                    </Link>
                  </div>
                </>
              )}
              {step === 1 && (
                <form noValidate onSubmit={prepare} className="lw-form">
                  <div className="lw-selection">
                    <span>
                      <Check size={13} />
                      {project?.short || "Design guidance"}
                      {configuration ? " · " + configuration : ""}
                    </span>
                    <button type="button" onClick={() => go(0)}>
                      <ArrowLeft size={12} /> Change
                    </button>
                  </div>
                  <ContactFields value={contact} onChange={update} />
                  {error && (
                    <p className="lx-error" role="alert">
                      {error}
                    </p>
                  )}
                  <button type="submit" className="button lw-primary">
                    <MessageCircle size={17} /> Prepare my quote request
                  </button>
                  <ContactDisclosure />
                </form>
              )}
              {step === 2 && (
                <EnquiryHandoff
                  title="Your ideas. Ready to share."
                  message={leadMessage(contact, context)}
                  onEdit={() => go(1)}
                />
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
