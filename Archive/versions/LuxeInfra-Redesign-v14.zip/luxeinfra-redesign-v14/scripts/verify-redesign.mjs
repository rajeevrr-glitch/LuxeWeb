// Read-only checks of the built release, without sending any customer messages.
import assert from "node:assert/strict";
import { access } from "node:fs/promises";
import path from "node:path";
import handler from "../dist/server/server.js";

const review = process.argv.includes("--review");
const routes = [
  "/",
  "/offers",
  "/partner-with-us",
  "/partner-with-us?role=careers",
  "/callback?offer=festive-15",
  "/estimate",
  "/plan",
  "/project-brief",
  "/design-ideas",
  "/design-ideas/kitchen",
  "/design-ideas/bedroom",
  "/materials",
  "/how-it-works",
  "/reimagine",
  "/about",
  "/contact",
  "/privacy",
  "/testimonials",
];
const assets = new Set();
for (const route of routes) {
  const response = await handler.fetch(new Request("http://localhost" + route));
  assert.equal(response.status, 200, route);
  const html = await response.text();
  assert.doesNotMatch(html, /This page didn't load/);
  assert.equal((html.match(/<h1[\s>]/g) || []).length, 1, "one main heading: " + route);
  if (route === "/") {
    assert.match(html, /Partner with LuxeInfra/);
    assert.equal(html.includes("Proposed festive offer"), review);
    assert.doesNotMatch(html.match(/<header[\s\S]*?<\/header>/)?.[0] || "", /Delhi NCR|Bengaluru/);
  }
  if (route === "/offers") {
    assert.equal(html.includes("not open for booking yet"), review);
    assert.equal(html.includes("There isn’t a bookable festive offer"), !review);
  }
  if (route === "/partner-with-us?role=careers") assert.match(html, /value="careers" selected/);
  if (route.startsWith("/callback?")) assert.equal(html.includes("Festive offer preview"), review);
  if (route === "/testimonials") assert.match(html, /Approved client stories will appear here/);
  for (const match of html.matchAll(/(?:src|href)="(\/assets\/[^"?#]+)[^"\s]*"/g))
    assets.add(match[1]);
}
for (const asset of assets) await access(path.join("dist/client", decodeURIComponent(asset)));
assert.equal((await handler.fetch(new Request("http://localhost/not-a-real-page"))).status, 404);
console.log(
  JSON.stringify({
    mode: review ? "review" : "public",
    routes: routes.length,
    builtAssets: assets.size,
    offerGate: "passed",
    partnerDeepLink: "passed",
    missingPage: 404,
  }),
);
