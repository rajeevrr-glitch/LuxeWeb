export const welcomeStorageKey = "luxeinfra-welcome-v1";
export function welcomeIsTimely(elapsedMs: number, explored: boolean, forced = false) {
  return forced || elapsedMs >= 30000 || (elapsedMs >= 12000 && explored);
}
const protectedJourneys = new Set([
  "/estimate",
  "/callback",
  "/plan",
  "/project-brief",
  "/reimagine",
  "/partner-with-us",
  "/privacy",
  "/contact",
  "/find-your-style",
  "/my-inspiration",
]);
export function welcomeIsEligible(pathname: string) {
  const path = pathname.replace(/\/+$/, "") || "/";
  return !protectedJourneys.has(path);
}
export function welcomeShouldOpen(
  pathname: string,
  seen: boolean,
  interacted: boolean,
  forced = false,
) {
  return welcomeIsEligible(pathname) && !interacted && (forced || !seen);
}
type WelcomeStorage = {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
};
// The memory fallback avoids repeat interruptions when browser storage is unavailable.
export function createWelcomeTracker(storage?: WelcomeStorage) {
  let seen = false;
  return {
    hasSeen() {
      if (seen) return true;
      try {
        return storage?.getItem(welcomeStorageKey) === "seen";
      } catch {
        return false;
      }
    },
    markSeen() {
      seen = true;
      try {
        storage?.setItem(welcomeStorageKey, "seen");
      } catch {
        /* The memory fallback still works. */
      }
    },
  };
}
