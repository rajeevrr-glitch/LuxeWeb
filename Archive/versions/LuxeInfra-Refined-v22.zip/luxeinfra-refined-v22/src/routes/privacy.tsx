import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { business } from "@/lib/business";
export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "Your project. Your information. — LuxeInfra" }] }),
  component: Page,
});
function Page() {
  return (
    <PageShell>
      <section className="wrap section">
        <div className="page-intro">
          <span className="eyebrow">LUXEINFRA / PRIVACY</span>
          <h1>Your project. Your information.</h1>
        </div>
        <div className="reading-copy">
          <p>This notice explains how this website handles your project information.</p>
          <h2>You choose when to contact us</h2>
          <p>
            When automatic submission is configured, the form shows Send my quote request (or Submit
            my brief / Send my introduction). Submitting sends your name, phone, city, project
            details and consent to LuxeInfra’s server. Your full text request is kept in private
            storage for the team to follow up. A summary and contact details are sent to the
            configured internal team number through the WhatsApp Business Platform. A reference
            confirms submission; it does not confirm a booking, quotation, or that a team member has
            read the notification. Photos and plans are not uploaded by this automatic submission.
          </p>
          <p>
            When the form offers Continue in WhatsApp, it follows the manual process below. If
            automatic submission cannot be confirmed, you can retry or use the manual WhatsApp
            fallback. Include any displayed reference so the team can check the existing request. A
            timeout does not prove that nothing arrived.
          </p>
          <h2>Manual WhatsApp and email sharing</h2>
          <p>
            In the manual flow, the short enquiry form and budget planner prepare your name, phone
            number, city, broad scope and any optional email or preferred call window. Continuing
            from the short quote form opens WhatsApp directly with these details in a draft. You
            still need to press Send in WhatsApp. An email draft is available as a fallback. Nothing
            is submitted to a website enquiry service, and this website cannot confirm message
            delivery. Continuing passes the draft details to WhatsApp through its link before you
            press Send; LuxeInfra receives the chat message only when you send it. The website does
            not save your contact details to browser storage.
          </p>
          <p>
            The budget planner saves your location, scope, approximate sizes and finish preferences
            in this browser tab’s session storage. These choices can carry into your enquiry when
            you choose to discuss your selection. Names, phone numbers, email addresses and
            preferred call windows are not saved to browser storage. They are sent to the server
            only when you explicitly submit using automatic delivery, or passed to an external app
            when you choose manual sharing. You can edit your choices before sending. Closing the
            tab ends this session; clearing website data also removes saved choices.
          </p>
          <h2>Partnership and career introductions</h2>
          <p>
            The partnership form prepares your interest, name, phone number, city and any optional
            organisation or introduction you add. When automatic submission is configured, these
            details follow the private-server and internal notification process above. Otherwise,
            continuing opens a WhatsApp draft for you to review and send yourself. Email remains
            available as a fallback. These details are not saved to browser storage. LuxeInfra uses
            the details you send to review and respond to your introduction.
          </p>
          <h2>The optional detailed brief</h2>
          <p>
            The planner brings together your room choices, city, contact details, notes and
            inspiration references. When automatic submission is configured, its full text is saved
            privately, with a summary notification sent to the team. Otherwise, continuing opens
            WhatsApp with your brief or a shorter introduction for long briefs. Press Send there to
            contact LuxeInfra. The full brief can also be downloaded in your browser.
          </p>
          <p>
            When using manual sharing, WhatsApp opens a message for you to review and send. Email
            opens a draft addressed to sales@luxeinfra.in, with infoluxeinfra@gmail.com copied.
            Download and attach your complete brief and any plans or photos yourself. These external
            services process information under their own policies. LuxeInfra uses the details you
            send to discuss and respond to your project enquiry.
          </p>
          <h2>Choices saved in your browser</h2>
          <p>
            The welcome invitation keeps a simple seen flag in this tab’s session storage so it does
            not keep interrupting your visit. This flag contains no contact details. Closing the
            welcome form clears its personal contact fields. You can use Get a quote to start again;
            the header quote button reopens the invitation on browsing pages.
          </p>
          <p>
            Room, work, style, and other non-contact preferences, along with saved inspiration
            ideas, are kept in your browser so you can return to them. Contact details and uploads
            are not saved in browser storage. Clearing this website’s browser data removes your
            saved preferences.
          </p>
          <p>
            The design comparison saves only selected design references and fixed preference tags,
            such as layout or colour palette. Any notes you type stay in the current page and can be
            included in a decision sheet only when you choose to download it. Planning-guide
            checklist ticks also stay on the current page. Leaving or refreshing clears these notes
            and checklist ticks; they are not automatically sent to LuxeInfra.
          </p>
          <h2>Room photos and image generation</h2>
          <p>
            Selected photos stay in the current tab while you prepare your room brief. They are not
            uploaded through the project planner. Leaving or refreshing the page may lose your
            unfinished brief. The public release does not enable AI generation; no photo is sent to
            an AI provider.
          </p>
          <h2>Website delivery</h2>
          <p>
            Your browser requests website files and fonts from the hosting and font services. Those
            services receive connection information such as your IP address. This website does not
            add advertising trackers or visitor analytics.
          </p>
          <h2>Questions or deletion requests</h2>
          <p>
            Contact <a href={"mailto:" + business.email}>{business.email}</a> about your project
            information, corrections or deletion requests. Automatic text submissions remain in
            LuxeInfra’s private hosting storage until managed by the team. Contact details and files
            shared through WhatsApp or email also remain in those receiving services until managed
            there. Closing a form or leaving the page does not withdraw a request already submitted.
          </p>
        </div>
      </section>
    </PageShell>
  );
}
