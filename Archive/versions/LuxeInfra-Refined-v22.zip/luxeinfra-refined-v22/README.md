# LuxeInfra website

Decision-support version 22 — 24 October 2026. Read NEXT-STEPS-V22.md for the current competitor-audit progress and remaining inputs, and QA-REPORT-V22.md for the checks. New: saved-design comparison, related room ideas and four practical planning guides. AUTOMATIC-DELIVERY-SETUP.md and owner-inputs/AUTOMATIC-DELIVERY-CONNECTION.md cover the account-ready integration, which remains disabled until connected. LAUNCH-CHECKLIST.md and LAUNCH-README.md cover deployment. Complete history: workdone.md.

## Run locally

Requires Node.js 24 or later. Install dependencies with `npm ci`.

- `npm run dev`: design development on port 5173, with the separate local-only AI/enquiry pilot services.
- `npm run build` then `npm start`: public-mode site on port 3000. Unapproved promotions and numerical prices are inactive.
- `npm run build:review` then `npm start`: local review with the proposed festive offer and clearly labelled sample client stories. Do not deploy this mode publicly.
- `npm run lint`, `npm run typecheck`, `npm test`, `npm run format:check`: quality checks.
- `node scripts/verify-redesign.mjs`: checks a public build; add `--review` after a review build.
- `npm run delivery:check`: checks automatic-delivery configuration offline, without sending or printing credentials.

Start-release.cmd builds and opens the local public release process; Start-preview.cmd starts development. Keep the terminal running while viewing the site. These commands do not publish it.

## Current visitor journeys

Room inspiration and saved ideas; style discovery; materials guidance; room-specific project planning; short quote enquiries; a budget/scope planner; room-photo briefing; and partnership/career introductions.

Saved ideas can now be compared in groups of up to three. Fixed preference tags can accompany the saved references in a quote request; optional notes are page-local and only enter an explicit direction-sheet download. The /guides collection adds four original planning articles, related reading, optional preparation checklists and contextual next steps. The quotation guide opens the existing process-page quotation checklist. No contact details are required to read or use these tools.

The planner begins with BHK/size and relevant interior choices. While approved rates are unavailable, it shows a scope summary without collecting contact details. Its optional quote action carries the selections forward. Numerical budgets and their later contact/result journey remain gated by approved rates. Quick quotes skip the project chooser when valid context is already supplied, otherwise start with project cards. Optional email/call preferences are page-local; delivery is a manual app handoff.

The welcome invitation opens once per tab session after 12 seconds plus browsing exploration, or after a 30-second visit. It waits around menus/dialogs/typing and excludes active form, privacy, contact and style-quiz journeys. The header quote action reopens it on eligible browsing pages; there is no floating invitation covering content. Readable mobile choices intentionally scroll within the panel. Personal fields clear on close; only a non-personal seen flag is stored. `/?welcome=1` explicitly previews the invitation. See QA-REPORT-V19.md for actual coverage.

Valid short quote, welcome, detailed-brief and partner submissions now open WhatsApp immediately with a prepared message for +91 9026271638. There is no extra required “request ready” click. The visitor still presses Send in WhatsApp. An on-page link supports browsers that block the new tab, and email is a secondary fallback. Long detailed briefs use a short introduction and explicitly ask the visitor to download and attach the full brief. Files must be attached manually. This is click-to-chat, not automatic API delivery; the website cannot confirm receipt.

Version 21 adds the owner's selected automatic flow: when fully configured, these forms submit to a private server, save the full text and send a WhatsApp template notification to the internal team. Only a saved request with provider acceptance shows success/reference; it opens no external app. Failed/uncertain responses preserve details and known references, with deliberate manual fallback. It is currently disabled because the account is not connected; the paragraph above describes the working fallback. The approved-price result offers submission only after the visitor reviews the budget. See AUTOMATIC-DELIVERY-SETUP.md before activation.

Numerical estimates need approved rates. Festive offers need approved dates and terms. The homepage and permanent Reviews navigation now show a client-stories section even before genuine reviews are supplied. The normal public build uses only approved, permissioned reviews, or an invitation to share an experience. Local review mode alone shows labelled layout examples. Public AI generation is disabled.

## Code and notes

- `src/routes`: page journeys; `src/components`: shared interface; `src/lib`: business details, room logic, pricing and publication controls.
- `src/styles.css`, `studio.css`, `refinement.css`, `launch.css`, `commerce.css`, `campaigns.css`, `reviews.css`, `sales.css`, `welcome.css`, `usability.css`, `guides.css`, `design-decisions.css`: ordered style layers for the retained theme, shared journeys and decision tools.
- `scripts/build-room-thumbnails.mjs`: regenerates the responsive room shortcuts from existing source images. Build configuration keeps them outside JavaScript so they can be loaded and cached as images.
- `scripts/production-server.mjs`: public Node server. Other enquiry/desk/AI scripts are local pilots and are not connected to public intake.
- `tests`: validation, pricing, server, privacy and pilot checks.
- `owner-inputs`: rates, catalogue, genuine content and commercial inputs still needed.
- `workdone.md`: chronological history; REDESIGN-V12/13/14 and earlier handover documents are historical references.

npm and package-lock.json are the dependency source of truth. The unused Bun lockfile, spare UI templates and obsolete Worker configuration have been removed. Keep private runtime data, credentials, caches, dependencies and generated build folders out of source handovers.

## Confirmed contacts

sales@luxeinfra.in, copied to infoluxeinfra@gmail.com. WhatsApp +91 9026271638; second call number +91 7678432743. Service areas: Uttar Pradesh, Delhi NCR and Bengaluru.

No live hosting, Lovable project or GoDaddy DNS was changed by this cleanup.
