import { Link } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { Check, Mail, MessageCircle, Phone } from "lucide-react";
import { business } from "@/lib/business";
import { callTimes, type LeadContact } from "@/lib/sales-funnel";

export function ContactFields({
  value,
  onChange,
}: {
  value: LeadContact;
  onChange: (key: keyof LeadContact, value: string) => void;
}) {
  return (
    <div className="lf-contact-fields">
      <div className="lf-input-pair">
        <label>
          Your name
          <input
            autoComplete="name"
            required
            maxLength={80}
            placeholder="e.g. Aarav Sharma"
            value={value.name}
            onChange={(e) => onChange("name", e.target.value)}
          />
        </label>
        <label>
          Mobile number
          <input
            autoComplete="tel"
            type="tel"
            inputMode="tel"
            required
            maxLength={20}
            placeholder="10-digit mobile number"
            value={value.phone}
            onChange={(e) => onChange("phone", e.target.value)}
          />
        </label>
      </div>
      <div className="lf-input-pair">
        <label>
          Where is your home?
          <input
            autoComplete="address-level2"
            required
            maxLength={100}
            placeholder="City / locality"
            value={value.city}
            onChange={(e) => onChange("city", e.target.value)}
          />
        </label>
        <label>
          Service region
          <select value={value.region} onChange={(e) => onChange("region", e.target.value)}>
            {[...business.areas, "Other"].map((region) => (
              <option key={region}>{region}</option>
            ))}
          </select>
        </label>
      </div>
      <details className="lf-contact-extra">
        <summary>
          <Phone size={15} /> Add a call preference or email <span>Optional</span>
        </summary>
        <div className="lf-input-pair">
          <label>
            Best time for a call
            <select value={value.callTime} onChange={(e) => onChange("callTime", e.target.value)}>
              {callTimes.map((time) => (
                <option key={time}>{time}</option>
              ))}
            </select>
            <small>IST. A preference, not a confirmed appointment.</small>
          </label>
          <label>
            Email address
            <input
              autoComplete="email"
              type="email"
              maxLength={160}
              placeholder="you@example.com"
              value={value.email}
              onChange={(e) => onChange("email", e.target.value)}
            />
          </label>
        </div>
      </details>
    </div>
  );
}

export function ContactDisclosure() {
  return (
    <p className="lf-disclosure">
      Nothing is sent automatically. Review your request next, then send it through WhatsApp or
      email. By sending, you ask LuxeInfra to contact you about this project.{" "}
      <Link to="/privacy">Privacy details</Link>
    </p>
  );
}

export function EnquiryHandoff({
  message,
  onEdit,
  title = "Your quote request is ready.",
}: {
  message: string;
  onEdit: () => void;
  title?: string;
}) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    heading.current?.focus();
  }, []);
  return (
    <div className="lf-handoff" aria-live="polite">
      <span className="lf-ready">
        <Check size={16} /> READY TO SHARE
      </span>
      <h2 ref={heading} tabIndex={-1}>
        {title}
      </h2>
      <p>
        One last step: send your request so the studio can get in touch. It hasn’t been sent yet.
      </p>
      <div className="lf-send-buttons">
        <a
          className="button lf-whatsapp"
          href={business.whatsapp + "?text=" + encodeURIComponent(message)}
          target="_blank"
          rel="noreferrer"
        >
          <MessageCircle size={19} /> Continue in WhatsApp
        </a>
        <a
          className="button secondary"
          href={
            "mailto:" +
            business.email +
            "?cc=" +
            encodeURIComponent(business.alternateEmail) +
            "&subject=" +
            encodeURIComponent("LuxeInfra interior quote request") +
            "&body=" +
            encodeURIComponent(message)
          }
        >
          <Mail size={18} /> Open email draft
        </a>
      </div>
      <details className="lf-message-preview">
        <summary>Review what you’re sharing</summary>
        <pre>{message}</pre>
      </details>
      <button type="button" className="lx-underlink" onClick={onEdit}>
        Edit my details
      </button>
      <small>
        Review and send in your chosen app. Attach a floor plan or photographs there if you’d like.
      </small>
    </div>
  );
}
