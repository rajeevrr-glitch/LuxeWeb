import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Phone, MessageCircle, Mail, Check, X } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { business, rooms } from "@/lib/business";
import { readEstimate, describeEstimate, type EstimateDraft } from "@/lib/estimate";
import { readInspiration, type Inspiration } from "@/lib/inspiration";
import image from "@/assets/living.jpg";

export const Route = createFileRoute("/callback")({
  validateSearch: (
    s: Record<string, unknown>,
  ): {
    city?: string;
    scope?: string;
    room?: string;
    style?: string;
    from?: string;
    material?: string;
  } => ({
    city: typeof s.city === "string" ? s.city.slice(0, 100) : undefined,
    scope: typeof s.scope === "string" ? s.scope.slice(0, 80) : undefined,
    room: typeof s.room === "string" && rooms.includes(s.room) ? s.room : undefined,
    style: typeof s.style === "string" ? s.style.slice(0, 80) : undefined,
    from: s.from === "estimate" ? "estimate" : undefined,
    material: typeof s.material === "string" ? s.material.slice(0, 80) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Talk to the studio — LuxeInfra" },
      { name: "robots", content: "noindex, follow" },
      {
        name: "description",
        content:
          "Share a short interior enquiry through WhatsApp or email, or call the LuxeInfra studio directly.",
      },
    ],
  }),
  component: Callback,
});
function Callback() {
  const search = Route.useSearch();
  const [draft, setDraft] = useState({
    name: "",
    phone: "",
    city: search.city || "",
    scope:
      search.scope === "Modular interiors"
        ? "Kitchen & wardrobes"
        : search.scope === "Whole home"
          ? "Whole home"
          : search.room
            ? "Selected rooms"
            : "Need guidance",
  });
  const [estimate, setEstimate] = useState<EstimateDraft | null>(null);
  const [inspiration, setInspiration] = useState<Inspiration[]>([]);
  const [includeIdeas, setIncludeIdeas] = useState(true);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    setInspiration(readInspiration());
    if (search.from === "estimate") {
      const saved = readEstimate();
      if (saved) {
        setEstimate(saved);
        setDraft((d) => ({
          ...d,
          city: saved.city + ", " + saved.region,
          scope:
            saved.scope === "Modular interiors"
              ? "Kitchen & wardrobes"
              : saved.scope === "Whole home"
                ? "Whole home"
                : "Selected rooms",
        }));
      }
    }
  }, [search.from]);
  const context = [
    estimate ? describeEstimate(estimate) : "",
    search.room ? "Room: " + search.room : "",
    search.style ? "Style direction: " + search.style : "",
    search.material ? "Material direction: " + search.material : "",
    includeIdeas && inspiration.length
      ? "Saved inspiration:\n" +
        inspiration.map((idea) => "- " + idea.title + " (ref: " + idea.id + ")").join("\n")
      : "",
  ]
    .filter(Boolean)
    .join("\n");
  const message =
    "Hello LuxeInfra, I’d like to discuss my interiors.\n\nName: " +
    draft.name.trim() +
    "\nPhone: " +
    draft.phone.trim() +
    "\nCity: " +
    draft.city.trim() +
    "\nInterested in: " +
    draft.scope +
    (context ? "\n\n" + context : "") +
    "\n\nPlease contact me about this enquiry.";
  function prepare(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!draft.name.trim() || !draft.city.trim()) {
      setError("Add your name and city to prepare your request.");
      return;
    }
    if (!/^(?:\+?91[ -]?)?[6-9]\d{9}$/.test(draft.phone.replace(/[()\s-]/g, ""))) {
      setError("Enter a valid 10-digit Indian mobile number, with or without +91.");
      return;
    }
    setReady(true);
    setError("");
  }
  function update(key: keyof typeof draft, value: string) {
    setDraft((d) => ({ ...d, [key]: value }));
    setReady(false);
    setError("");
  }
  return (
    <PageShell>
      <section className="wrap lx-callback-layout">
        <div className="lx-callback-story">
          <img src={image} alt="Warm, inviting living room inspiration" width="1024" height="768" />
          <div>
            <span className="eyebrow">A HOME BEGINS WITH A CONVERSATION</span>
            <h1>
              Your ideas.
              <br />
              Let’s hear <em>them.</em>
            </h1>
            <p>A first home, a fresh start or a favourite room. Tell us what you’re thinking.</p>
            <div className="lx-direct-call">
              <span>Prefer to talk now?</span>
              <a href={business.phoneHref}>
                <Phone size={16} />
                {business.phone}
              </a>
              <a href={business.secondaryPhoneHref}>{business.secondaryPhone}</a>
            </div>
          </div>
        </div>
        <div className="lx-callback-form">
          <span className="eyebrow">LET’S MAKE ROOM FOR YOU</span>
          <h2>Keep it simple.</h2>
          <p>Just the essentials. You can share the details when we talk.</p>
          <form onSubmit={prepare} className="lx-form-fields">
            <label>
              Your name
              <input
                autoComplete="name"
                value={draft.name}
                maxLength={80}
                onChange={(e) => update("name", e.target.value)}
                required
                placeholder="What should we call you?"
              />
            </label>
            <label>
              Mobile number
              <input
                autoComplete="tel"
                inputMode="tel"
                type="tel"
                value={draft.phone}
                maxLength={20}
                onChange={(e) => update("phone", e.target.value)}
                required
                placeholder="+91"
              />
            </label>
            <div className="lx-fields-two">
              <label>
                City / locality
                <input
                  autoComplete="address-level2"
                  value={draft.city}
                  maxLength={100}
                  onChange={(e) => update("city", e.target.value)}
                  required
                  placeholder="Where is your space?"
                />
              </label>
              <label>
                You’re considering
                <select value={draft.scope} onChange={(e) => update("scope", e.target.value)}>
                  {[
                    "Whole home",
                    "Kitchen & wardrobes",
                    "Selected rooms",
                    "Renovation",
                    "Need guidance",
                  ].map((scope) => (
                    <option key={scope}>{scope}</option>
                  ))}
                </select>
              </label>
            </div>
            {search.material && (
              <p className="lx-inline-note">Material direction to discuss: {search.material}</p>
            )}
            {estimate && (
              <div className="lx-context-note">
                <div>
                  <Check size={16} />
                  <strong>Your budget selections are included</strong>
                  <button
                    type="button"
                    aria-label="Remove budget selections from request"
                    onClick={() => setEstimate(null)}
                  >
                    <X size={16} />
                  </button>
                </div>
                <p>
                  {estimate.scope} · {estimate.finish}
                </p>
                <Link to="/estimate" className="lx-underlink">
                  Review selections
                </Link>
              </div>
            )}
            {inspiration.length > 0 && (
              <label className="lx-checkbox">
                <input
                  type="checkbox"
                  checked={includeIdeas}
                  onChange={(e) => {
                    setIncludeIdeas(e.target.checked);
                    setReady(false);
                  }}
                />
                Include my {inspiration.length} saved inspiration{" "}
                {inspiration.length === 1 ? "idea" : "ideas"}
              </label>
            )}
            {error && (
              <p className="lx-error" role="alert">
                {error}
              </p>
            )}
            {!ready && (
              <>
                <button type="submit" className="button">
                  <MessageCircle size={17} /> Choose how to send
                </button>
                <p className="lx-form-disclosure">
                  You’ll review and send a short request in WhatsApp or your email app. Nothing is
                  sent automatically. By sending, you ask LuxeInfra to contact you about this
                  enquiry. <Link to="/privacy">Privacy details</Link>
                </p>
              </>
            )}
          </form>
          {ready && (
            <div className="lx-send-options" aria-live="polite">
              <h3>Your request is ready.</h3>
              <p>Choose one way to send it. Your request hasn’t been sent yet.</p>
              <a
                className="button"
                href={business.whatsapp + "?text=" + encodeURIComponent(message)}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle size={18} /> Open WhatsApp
              </a>
              <a
                className="button secondary"
                href={
                  "mailto:" +
                  business.email +
                  "?cc=" +
                  encodeURIComponent(business.alternateEmail) +
                  "&subject=" +
                  encodeURIComponent("LuxeInfra interior enquiry") +
                  "&body=" +
                  encodeURIComponent(message)
                }
              >
                <Mail size={18} /> Open email draft
              </a>
              <details>
                <summary>Preview my request</summary>
                <pre>{message}</pre>
              </details>
              <button className="lx-underlink" onClick={() => setReady(false)}>
                Edit my details
              </button>
              <small>
                Complete sending in the app you choose. We can respond after your message reaches
                us.
              </small>
            </div>
          )}
          <div className="lx-contact-footnote">
            <span>Want to explore first?</span>{" "}
            <Link to="/design-ideas" className="lx-underlink">
              Browse the inspiration edit
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
