import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import { Check, Calculator, Layers, Phone, RotateCcw } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { business, rooms } from "@/lib/business";
import {
  emptyEstimate,
  estimateScopes,
  calculateEstimate,
  saveEstimate,
  readEstimate,
  type EstimateDraft,
} from "@/lib/estimate";
import kitchen from "@/assets/kitchen.jpg";
import home from "@/assets/full-home.jpg";
import bedroom from "@/assets/bedroom.jpg";

export const Route = createFileRoute("/estimate")({
  validateSearch: (
    s: Record<string, unknown>,
  ): { scope?: string; room?: string; style?: string } => ({
    scope: typeof s.scope === "string" ? s.scope.slice(0, 80) : undefined,
    room: typeof s.room === "string" && rooms.includes(s.room) ? s.room : undefined,
    style: typeof s.style === "string" ? s.style.slice(0, 80) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Explore your interiors budget — LuxeInfra" },
      { name: "robots", content: "noindex, follow" },
      {
        name: "description",
        content:
          "Choose modular interiors, a whole home or selected rooms. Explore your specifications without sharing contact details.",
      },
    ],
  }),
  component: Estimate,
});
function Estimate() {
  const search = Route.useSearch();
  const [draft, setDraft] = useState<EstimateDraft>(emptyEstimate);
  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const heading = useRef<HTMLHeadingElement>(null);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const saved = readEstimate();
    const scope = estimateScopes.includes(search.scope as EstimateDraft["scope"])
      ? (search.scope as EstimateDraft["scope"])
      : search.room
        ? "Selected rooms"
        : undefined;
    setDraft({
      ...(saved || emptyEstimate),
      ...(scope ? { scope } : {}),
      ...(search.room ? { rooms: [search.room] } : {}),
    });
    setLoaded(true);
  }, [search.scope, search.room]);
  useEffect(() => {
    if (loaded) saveEstimate(draft);
  }, [draft, loaded]);
  function update<K extends keyof EstimateDraft>(key: K, value: EstimateDraft[K]) {
    setDraft((old) => ({ ...old, [key]: value }));
    setError("");
  }
  function go(next: number) {
    setStep(next);
    setError("");
    requestAnimationFrame(() => {
      heading.current?.focus();
      heading.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }
  function next() {
    if (step === 0 && !draft.city.trim()) {
      setError("Tell us your city or locality to continue.");
      return;
    }
    if (step === 1 && draft.scope === "Modular interiors" && !draft.kitchen && !draft.wardrobes) {
      setError("Choose a kitchen, wardrobes or both.");
      return;
    }
    if (step === 1 && draft.scope === "Selected rooms" && !draft.rooms.length) {
      setError("Choose at least one room.");
      return;
    }
    go(step + 1);
  }
  const result = calculateEstimate(draft);
  const formatter = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  });
  const selections =
    draft.scope === "Modular interiors"
      ? [draft.kitchen && "Kitchen", draft.wardrobes && "Wardrobes"].filter(Boolean).join(" + ")
      : draft.scope === "Whole home"
        ? draft.configuration
        : draft.rooms.join(", ");
  return (
    <PageShell>
      <section className="wrap lx-page-intro lx-estimate-intro">
        <div>
          <span className="eyebrow">A LITTLE CLARITY BEFORE THE BIG DECISIONS</span>
          <h1>
            Your vision.
            <br />A more considered <em>budget.</em>
          </h1>
        </div>
        <p>
          Start with a few choices. No phone number needed to explore. Pricing depends on approved
          specifications and the work your space needs.
        </p>
      </section>
      <section className="wrap lx-estimator">
        <div className="lx-estimate-main">
          <ol className="lx-progress" aria-label="Planning progress">
            {["Your space", "Your scope", "Your finish", "Your selection"].map((label, i) => (
              <li key={label} aria-current={step === i ? "step" : undefined}>
                <span>{step > i ? <Check size={13} /> : i + 1}</span>
                <small>{label}</small>
              </li>
            ))}
          </ol>
          <h2 ref={heading} tabIndex={-1}>
            {
              [
                "Where are we beginning?",
                "What would you like to create?",
                "What feels like you?",
                result.status === "priced"
                  ? "Your indicative budget."
                  : "Your ideas, taking shape.",
              ][step]
            }
          </h2>
          {step === 0 && (
            <div className="lx-form-fields">
              <div className="lx-fields-two">
                <label>
                  Service region
                  <select value={draft.region} onChange={(e) => update("region", e.target.value)}>
                    {[...business.areas, "Other"].map((region) => (
                      <option key={region}>{region}</option>
                    ))}
                  </select>
                </label>
                <label>
                  City / locality
                  <input
                    autoComplete="address-level2"
                    maxLength={100}
                    value={draft.city}
                    onChange={(e) => update("city", e.target.value)}
                    placeholder="e.g. Noida, Gomti Nagar"
                  />
                </label>
              </div>
              <fieldset>
                <legend>Your space is a…</legend>
                <div className="lx-options">
                  {["New home", "Renovation"].map((condition) => (
                    <button
                      key={condition}
                      type="button"
                      aria-pressed={draft.condition === condition}
                      onClick={() => update("condition", condition)}
                    >
                      {condition}
                    </button>
                  ))}
                </div>
              </fieldset>
              <fieldset>
                <legend>What are you planning?</legend>
                <div className="lx-scope-choices">
                  {estimateScopes.map((scope, i) => (
                    <button
                      key={scope}
                      type="button"
                      aria-pressed={draft.scope === scope}
                      onClick={() => update("scope", scope)}
                    >
                      <img src={[kitchen, home, bedroom][i]} alt="" />
                      <strong>{scope}</strong>
                      <span>
                        {["Kitchen & wardrobes", "A coordinated home", "Your chosen rooms"][i]}
                      </span>
                    </button>
                  ))}
                </div>
              </fieldset>
              {draft.region === "Other" && (
                <p className="lx-inline-note">
                  Share your location and we’ll discuss whether arrangements are possible. A price
                  will need individual review.
                </p>
              )}
            </div>
          )}
          {step === 1 && (
            <div className="lx-form-fields">
              {draft.scope === "Modular interiors" && (
                <>
                  <fieldset>
                    <legend>Choose the work</legend>
                    <div className="lx-options">
                      <button
                        type="button"
                        aria-pressed={draft.kitchen}
                        onClick={() => update("kitchen", !draft.kitchen)}
                      >
                        Kitchen
                      </button>
                      <button
                        type="button"
                        aria-pressed={draft.wardrobes}
                        onClick={() => update("wardrobes", !draft.wardrobes)}
                      >
                        Wardrobes
                      </button>
                    </div>
                  </fieldset>
                  <p>
                    Measurements are optional. If you know the total cabinet front area, add it
                    below. Otherwise, leave it for the designer.
                  </p>
                  <div className="lx-fields-two">
                    {draft.kitchen && (
                      <label>
                        Total kitchen cabinet frontage (sq ft)
                        <input
                          type="number"
                          min="1"
                          max="100000"
                          step="any"
                          value={draft.kitchenArea}
                          onChange={(e) => update("kitchenArea", e.target.value)}
                          placeholder="Leave blank if unsure"
                        />
                      </label>
                    )}
                    {draft.wardrobes && (
                      <label>
                        Total wardrobe frontage (sq ft)
                        <input
                          type="number"
                          min="1"
                          max="100000"
                          step="any"
                          value={draft.wardrobeArea}
                          onChange={(e) => update("wardrobeArea", e.target.value)}
                          placeholder="Leave blank if unsure"
                        />
                      </label>
                    )}
                  </div>
                  <details className="lx-help">
                    <summary>How do I measure cabinet frontage?</summary>
                    <p>
                      For each cabinet run, multiply the front width by the cabinet height in feet,
                      then add the areas. Count base and wall cabinets separately. Wardrobes use
                      front width × height across all units. This is different from your room’s
                      floor area. The studio will confirm quantities and the pricing basis.
                    </p>
                  </details>
                </>
              )}
              {draft.scope === "Whole home" && (
                <>
                  <fieldset>
                    <legend>Your home configuration</legend>
                    <div className="lx-options">
                      {["1 BHK", "2 BHK", "3 BHK", "4+ BHK"].map((config) => (
                        <button
                          key={config}
                          type="button"
                          aria-pressed={draft.configuration === config}
                          onClick={() => update("configuration", config)}
                        >
                          {config}
                        </button>
                      ))}
                    </div>
                  </fieldset>
                  <label>
                    Carpet area in sq ft <span className="lx-optional">(optional)</span>
                    <input
                      type="number"
                      min="1"
                      max="100000"
                      value={draft.area}
                      onChange={(e) => update("area", e.target.value)}
                      placeholder="Your usable internal floor area"
                    />
                  </label>
                  <p className="lx-inline-note">
                    The rooms included, quantities and site work will be confirmed in your
                    quotation. Carpet area helps us understand the scale; it doesn’t determine the
                    final price on its own.
                  </p>
                </>
              )}
              {draft.scope === "Selected rooms" && (
                <fieldset>
                  <legend>Which rooms are on your mind?</legend>
                  <div className="lx-options">
                    {rooms.map((room) => (
                      <button
                        key={room}
                        type="button"
                        aria-pressed={draft.rooms.includes(room)}
                        onClick={() =>
                          update(
                            "rooms",
                            draft.rooms.includes(room)
                              ? draft.rooms.filter((r) => r !== room)
                              : [...draft.rooms, room],
                          )
                        }
                      >
                        {room}
                      </button>
                    ))}
                  </div>
                  <p className="lx-inline-note">
                    We’ll discuss the relevant work for these rooms. You don’t need to complete a
                    room-by-room form now.
                  </p>
                </fieldset>
              )}
            </div>
          )}
          {step === 2 && (
            <div className="lx-form-fields">
              <p>
                Start with a surface preference. We’ll discuss suitability, boards, hardware and
                samples before a specification is final.
              </p>
              <fieldset>
                <legend>Cabinet finish preference</legend>
                <div className="lx-finish-options">
                  {[
                    [
                      "Laminate",
                      "A layered surface with a wide range of design directions.",
                      "lx-oak",
                    ],
                    [
                      "Acrylic",
                      "A polished look to discuss alongside care and specification.",
                      "lx-blue",
                    ],
                    [
                      "Discuss with designer",
                      "Keep your options open. Let the space and your needs lead.",
                      "lx-ivory-swatch",
                    ],
                  ].map(([finish, desc, swatch]) => (
                    <button
                      key={finish}
                      aria-pressed={draft.finish === finish}
                      onClick={() => update("finish", finish)}
                    >
                      <span className={"lx-finish-swatch " + swatch} />
                      <strong>{finish}</strong>
                      <small>{desc}</small>
                    </button>
                  ))}
                </div>
              </fieldset>
              <Link to="/materials" className="lx-underlink" target="_blank">
                Get to know your materials
              </Link>
              {search.style && <p>Your saved style direction: {search.style}</p>}
            </div>
          )}
          {step === 3 && (
            <div className="lx-estimate-result" aria-live="polite">
              <span className="lx-icon">
                <Calculator size={25} />
              </span>
              {result.status === "priced" ? (
                <>
                  <div className="lx-price">
                    {formatter.format(result.min!)} – {formatter.format(result.max!)}
                  </div>
                  <p>{result.reason}</p>
                  <p>{result.taxNote}</p>
                  {result.lines.map((line) => (
                    <details key={line.id}>
                      <summary>
                        {line.id} · {line.quantity} {line.unit}
                      </summary>
                      <p>Includes: {line.inclusions.join(", ")}</p>
                      <p>Excludes: {line.exclusions.join(", ")}</p>
                    </details>
                  ))}
                  <small>Rate version: {result.version}</small>
                </>
              ) : (
                <>
                  <h3>Let’s price your space properly.</h3>
                  <p>
                    {result.reason} Share this short selection with the studio for a tailored
                    discussion. You won’t be asked to start over.
                  </p>
                  <p className="lx-inline-note">
                    Instant numerical estimates will be available once our specification-based rate
                    list is approved.
                  </p>
                </>
              )}
              <div className="lx-actions">
                <Link
                  to="/callback"
                  search={{ from: "estimate", style: search.style }}
                  className="button"
                >
                  <Phone size={17} /> Discuss this selection
                </Link>
                <button className="lx-underlink" onClick={() => go(0)}>
                  <RotateCcw size={15} /> Edit my choices
                </button>
              </div>
            </div>
          )}
          {error && (
            <p className="lx-error" role="alert">
              {error}
            </p>
          )}
          {step < 3 && (
            <div className="lx-step-actions">
              {step > 0 ? (
                <button type="button" className="lx-underlink" onClick={() => go(step - 1)}>
                  Back
                </button>
              ) : (
                <span>No contact details required</span>
              )}
              <button type="button" className="button" onClick={next}>
                {step === 2 ? "Review my selection" : "Continue"}
              </button>
            </div>
          )}
        </div>
        <aside className="lx-estimate-aside">
          <img
            src={
              draft.scope === "Whole home"
                ? home
                : draft.scope === "Selected rooms"
                  ? bedroom
                  : kitchen
            }
            alt="Interior design inspiration"
            width="600"
            height="500"
          />
          <div>
            <span className="eyebrow">YOUR STARTING POINT</span>
            <h3>A home, taking shape.</h3>
            <dl>
              <div>
                <dt>Location</dt>
                <dd>
                  {draft.city || "Your city"} · {draft.region}
                </dd>
              </div>
              <div>
                <dt>Scope</dt>
                <dd>
                  {draft.scope}
                  <br />
                  {selections || "Choose your work"}
                  {draft.scope === "Whole home" && draft.area && (
                    <>
                      <br />
                      {draft.area} sq ft carpet area
                    </>
                  )}
                  {draft.scope === "Modular interiors" && draft.kitchen && draft.kitchenArea && (
                    <>
                      <br />
                      Kitchen: {draft.kitchenArea} sq ft frontage
                    </>
                  )}
                  {draft.scope === "Modular interiors" && draft.wardrobes && draft.wardrobeArea && (
                    <>
                      <br />
                      Wardrobes: {draft.wardrobeArea} sq ft frontage
                    </>
                  )}
                </dd>
              </div>
              <div>
                <dt>Direction</dt>
                <dd>
                  {draft.finish}
                  <br />
                  {draft.condition}
                  {search.style && (
                    <>
                      <br />
                      {search.style}
                    </>
                  )}
                </dd>
              </div>
            </dl>
            <p>
              <Layers size={16} /> Scope. Materials. Clarity.
            </p>
            <small>Your choices stay in this browser tab until you choose to share them.</small>
            <button
              type="button"
              className="lx-underlink lx-reset-selection"
              onClick={() => {
                setDraft({ ...emptyEstimate, rooms: [] });
                go(0);
              }}
            >
              Start a fresh selection
            </button>
          </div>
        </aside>
      </section>
    </PageShell>
  );
}
