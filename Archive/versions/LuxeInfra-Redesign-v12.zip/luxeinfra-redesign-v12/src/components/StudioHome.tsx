import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Calculator, Phone, Check, Plus, Layers, Heart, Ruler, Sparkles } from "lucide-react";
import { PageShell } from "./PageShell";
import { ClientStories } from "./ClientStories";
import { faqs } from "@/lib/business";
import { spaces } from "@/lib/spaces";
import hero from "@/assets/hero-living.jpg";
import kitchen from "@/assets/kitchen.jpg";
import bedroom from "@/assets/bedroom.jpg";
import living from "@/assets/living.jpg";
import wardrobe from "@/assets/wardrobe.jpg";
import fullHome from "@/assets/full-home.jpg";

const roomEdits = [
  {
    slug: "kitchen",
    title: "A kitchen with a place for everything.",
    description: "Morning coffee. Family recipes. Everyday rituals. Make room for all of it.",
    image: kitchen,
    details: ["Layouts that flow", "Storage that works", "Finishes to make it yours"],
  },
  {
    slug: "living",
    title: "The room everyone comes back to.",
    description: "Good company, a favourite corner, and the comfort of being home.",
    image: living,
    details: ["Thoughtful seating", "Integrated storage", "Layers of light"],
  },
  {
    slug: "bedroom",
    title: "A little quiet. A lot of you.",
    description: "A softer palette, a calmer routine, and a space to switch off.",
    image: bedroom,
    details: ["Restful layouts", "Bedside essentials", "Personal details"],
  },
  {
    slug: "wardrobe",
    title: "Beautiful outside. Brilliant inside.",
    description: "Storage shaped around what you own and how you start your day.",
    image: wardrobe,
    details: ["Useful internal divisions", "Hinged or sliding doors", "Hardware to discuss"],
  },
];

export function StudioHome() {
  const [selected, setSelected] = useState(0);
  const edit = roomEdits[selected];
  return (
    <PageShell>
      <section className="lx-hero" aria-labelledby="home-title">
        <img
          className="lx-hero-image"
          src={hero}
          alt="Warm living room with ivory seating, wood panelling and abundant natural light"
          fetchPriority="high"
          width="1920"
          height="1080"
        />
        <div className="lx-hero-shade" />
        <div className="wrap lx-hero-inner">
          <div className="lx-hero-copy">
            <span className="eyebrow">THE WAY YOU LIVE. BEAUTIFULLY REIMAGINED.</span>
            <h1 id="home-title">
              Not just a home.
              <br />A little more <em>you.</em>
            </h1>
            <p>
              Thoughtful interiors, from one favourite room to your whole home. Made around your
              life, your taste, your everyday.
            </p>
            <div className="lx-actions">
              <Link to="/callback" className="button lx-ivory">
                <Phone size={17} /> Let’s talk interiors
              </Link>
              <Link to="/design-ideas" className="lx-hero-browse">
                Find your inspiration
              </Link>
            </div>
          </div>
          <div className="lx-hero-label">
            <span>THE LUXEINFRA EDIT</span>
            <strong>Warmth in every detail.</strong>
            <small>Living room inspiration</small>
          </div>
        </div>
      </section>
      <div className="wrap lx-start-bar">
        <div>
          <span className="eyebrow">A BEAUTIFUL PLACE TO START</span>
          <h2>Your home. Your way.</h2>
        </div>
        <Link to="/estimate">
          <span className="lx-icon">
            <Calculator size={22} />
          </span>
          <span>
            <strong>Explore your budget</strong>
            <small>Choose your scope and specifications</small>
          </span>
        </Link>
        <Link to="/callback">
          <span className="lx-icon">
            <Phone size={21} />
          </span>
          <span>
            <strong>Talk to the studio</strong>
            <small>A few details. A real conversation.</small>
          </span>
        </Link>
      </div>
      <section className="wrap lx-section">
        <div className="lx-heading">
          <div>
            <span className="eyebrow">SMALL CORNERS. BIG POSSIBILITIES.</span>
            <h2>
              Every space has a story.
              <br />
              <em>What’s yours?</em>
            </h2>
          </div>
          <Link to="/design-ideas" className="lx-underlink">
            Browse all spaces
          </Link>
        </div>
        <div className="lx-room-grid">
          {spaces.slice(0, 6).map((space) => (
            <Link
              to="/design-ideas/$category"
              params={{ category: space.slug }}
              className="lx-room-card"
              key={space.slug}
            >
              <div>
                <img
                  src={space.image}
                  alt={space.title + " design inspiration"}
                  loading="lazy"
                  width="600"
                  height="680"
                />
                <span>Explore the edit</span>
              </div>
              <h3>{space.title}</h3>
              <p>{space.line}</p>
            </Link>
          ))}
        </div>
        <p className="lx-caption">
          The inspiration collection · Images illustrate design directions.
        </p>
      </section>
      <section className="lx-room-edit">
        <div className="wrap lx-section">
          <div className="lx-heading">
            <div>
              <span className="eyebrow">GOOD DESIGN GOES DEEPER</span>
              <h2>
                Looks you’ll love.
                <br />
                <em>Details you’ll live with.</em>
              </h2>
            </div>
            <p>Start with the room. Get inspired by the details that make it work.</p>
          </div>
          <div className="lx-tabs" role="group" aria-label="Choose a room to explore">
            {roomEdits.map((room, i) => (
              <button key={room.slug} aria-pressed={selected === i} onClick={() => setSelected(i)}>
                {["Kitchen", "Living room", "Bedroom", "Wardrobe"][i]}
              </button>
            ))}
          </div>
          <div className="lx-feature-edit">
            <img
              src={edit.image}
              alt={edit.slug + " interior inspiration"}
              loading="lazy"
              width="1024"
              height="768"
            />
            <div className="lx-feature-copy">
              <span className="eyebrow">THE {edit.slug.toUpperCase()} EDIT</span>
              <h3>{edit.title}</h3>
              <p>{edit.description}</p>
              <ul>
                {edit.details.map((detail) => (
                  <li key={detail}>
                    <Check size={16} />
                    {detail}
                  </li>
                ))}
              </ul>
              <Link
                to="/design-ideas/$category"
                params={{ category: edit.slug }}
                className="button"
              >
                Explore{" "}
                {edit.slug === "living"
                  ? "living rooms"
                  : edit.slug === "wardrobe"
                    ? "wardrobes"
                    : edit.slug + "s"}
              </Link>
            </div>
          </div>
        </div>
      </section>
      <section className="wrap lx-section">
        <div className="lx-heading">
          <div>
            <span className="eyebrow">A ROOM, OR A FRESH START</span>
            <h2>
              Big plans.
              <br />
              <em>Personal starting points.</em>
            </h2>
          </div>
          <p>Bring us a single space or a whole-home vision. Start with what matters to you.</p>
        </div>
        <div className="lx-scope-grid">
          <Link to="/estimate" search={{ scope: "Modular interiors" }} className="lx-scope-card">
            <img src={kitchen} alt="Kitchen cabinetry and worktop inspiration" loading="lazy" />
            <div>
              <span className="eyebrow">THE EVERYDAY ESSENTIALS</span>
              <h3>Modular interiors</h3>
              <p>Kitchens, wardrobes and storage, planned around your routines.</p>
              <span className="lx-pill">Build your selection</span>
            </div>
          </Link>
          <Link to="/estimate" search={{ scope: "Whole home" }} className="lx-scope-card">
            <img src={fullHome} alt="Coordinated open-plan home inspiration" loading="lazy" />
            <div>
              <span className="eyebrow">THE BIGGER PICTURE</span>
              <h3>Whole-home interiors</h3>
              <p>A considered look across rooms, with the scope and details brought together.</p>
              <span className="lx-pill">Explore your home</span>
            </div>
          </Link>
        </div>
      </section>
      <section className="lx-material-band">
        <div className="wrap lx-material-layout">
          <div>
            <span className="eyebrow">BEAUTY IS IN THE SPECIFICATION</span>
            <h2>
              Look closer.
              <br />
              Choose <em>better.</em>
            </h2>
            <p>
              The finish you see is only part of the story. Get to know the boards, surfaces and
              hardware behind a well-planned space.
            </p>
            <Link to="/materials" className="button light">
              <Layers size={18} /> Explore materials
            </Link>
          </div>
          <div className="lx-swatch-board" aria-label="Illustrative material palette">
            <div className="lx-swatch lx-oak">
              <span>Wood tones</span>
            </div>
            <div className="lx-swatch lx-stone">
              <span>Stone textures</span>
            </div>
            <div className="lx-swatch lx-ivory-swatch">
              <span>Soft neutrals</span>
            </div>
            <div className="lx-swatch lx-blue">
              <span>Architectural blue</span>
            </div>
            <p>An illustrative palette. Review physical samples before approval.</p>
          </div>
        </div>
      </section>
      <section className="wrap lx-section lx-personal-grid">
        <div className="lx-style-card">
          <img src={bedroom} alt="A layered, natural bedroom palette" loading="lazy" />
          <div>
            <span className="eyebrow">LESS SCROLLING. MORE YOU.</span>
            <h2>
              Find your
              <br />
              <em>design personality.</em>
            </h2>
            <Link to="/find-your-style" className="button light">
              <Heart size={17} /> Find my style
            </Link>
          </div>
        </div>
        <div className="lx-studio-card">
          <span className="eyebrow">YOUR SPACE, IN FOCUS</span>
          <div className="lx-room-line" aria-hidden="true">
            <Ruler size={55} strokeWidth={1} />
            <span>
              YOUR ROOM
              <br />
              YOUR POSSIBILITIES
            </span>
          </div>
          <h2>
            Have a room
            <br />
            in <em>mind?</em>
          </h2>
          <p>
            Add a photo, dimensions and your ideas. Build a room brief to discuss with our studio.
          </p>
          <Link to="/reimagine" className="button">
            <Sparkles size={17} /> Open room studio
          </Link>
        </div>
      </section>
      <section className="lx-process-section">
        <div className="wrap lx-section">
          <div className="lx-heading">
            <div>
              <span className="eyebrow">FROM THE FIRST WHAT-IF</span>
              <h2>
                A clearer path
                <br />
                <em>to feeling at home.</em>
              </h2>
            </div>
            <Link to="/how-it-works" className="lx-underlink">
              See the full process
            </Link>
          </div>
          <div className="lx-process-grid">
            {[
              [
                "01",
                "Begin with you",
                "Your space, your priorities, your ideas. A conversation sets the direction.",
              ],
              [
                "02",
                "Bring it together",
                "Review layouts, material choices and an itemised scope before deciding.",
              ],
              [
                "03",
                "Make it happen",
                "Agree the work and schedule, then review progress and approved changes.",
              ],
              [
                "04",
                "Settle in",
                "Walk through the work together and review the applicable care and support.",
              ],
            ].map(([n, title, text]) => (
              <div key={n}>
                <span>{n}</span>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="wrap lx-section lx-local">
        <div>
          <span className="eyebrow">LET’S BRING IT HOME</span>
          <h2>
            Closer to
            <br />
            <em>your next chapter.</em>
          </h2>
          <p>
            Interiors across Uttar Pradesh, Delhi NCR and Bengaluru. Share your city so we can
            confirm arrangements for your site.
          </p>
          <Link to="/callback" className="button">
            Discuss my space
          </Link>
        </div>
        <div className="lx-region-list">
          {[
            ["01", "Uttar Pradesh"],
            ["02", "Delhi NCR"],
            ["03", "Bengaluru"],
          ].map(([n, city]) => (
            <Link to="/callback" search={{ city }} key={city}>
              <span>{n}</span>
              <h3>{city}</h3>
              <span className="lx-region-tag">Let’s talk</span>
            </Link>
          ))}
        </div>
      </section>
      <ClientStories />
      <section className="wrap lx-section lx-faq">
        <div>
          <span className="eyebrow">BEFORE YOU BEGIN</span>
          <h2>
            A little clarity.
            <br />
            <em>A better start.</em>
          </h2>
          <p>Still have a question? We’d love to talk.</p>
          <a className="lx-underlink" href="tel:+919026271638">
            Call the studio
          </a>
        </div>
        <div>
          {faqs.map(([q, a]) => (
            <details key={q}>
              <summary>
                {q}
                <Plus size={18} />
              </summary>
              <p>{a}</p>
            </details>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
