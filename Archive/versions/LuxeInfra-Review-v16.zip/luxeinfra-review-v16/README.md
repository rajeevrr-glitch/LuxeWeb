# LuxeInfra website

Review and browser-check version 16 — 22 October 2026. Read LAUNCH-CHECKLIST.md for the remaining decisions and LAUNCH-README.md for deployment instructions. The full work history is in workdone.md; current browser evidence is described in QA-REPORT-V16.md.

## Run locally

Requires Node.js 24 or later. Install dependencies with `npm ci`.

- `npm run dev`: design development on port 5173, with the separate local-only AI/enquiry pilot services.
- `npm run build` then `npm start`: public-mode site on port 3000. Unapproved promotions and numerical prices are inactive.
- `npm run build:review` then `npm start`: local review with the proposed festive offer and clearly labelled sample client stories. Do not deploy this mode publicly.
- `npm run lint`, `npm run typecheck`, `npm test`, `npm run format:check`: quality checks.
- `node scripts/verify-redesign.mjs`: checks a public build; add `--review` after a review build.

Start-release.cmd builds and opens the local public release process; Start-preview.cmd starts development. Keep the terminal running while viewing the site. These commands do not publish it.

## Current visitor journeys

Room inspiration and saved ideas; style discovery; materials guidance; room-specific project planning; short quote enquiries; a budget/scope planner; room-photo briefing; and partnership/career introductions.

Short enquiries prepare WhatsApp/email drafts. The visitor reviews and sends them. Files must be attached in the selected app. The website does not automatically send messages, upload customer files or confirm receipt.

Numerical estimates need approved rates. Festive offers need approved dates and terms. The homepage and permanent Reviews navigation now show a client-stories section even before genuine reviews are supplied. The normal public build uses only approved, permissioned reviews, or an invitation to share an experience. Local review mode alone shows labelled layout examples. Public AI generation is disabled.

## Code and notes

- `src/routes`: page journeys; `src/components`: shared interface; `src/lib`: business details, room logic, pricing and publication controls.
- `src/styles.css`, `studio.css`, `refinement.css`, `launch.css`, `commerce.css`, `campaigns.css`, `reviews.css`: ordered style layers, including the responsive client-stories layout.
- `scripts/production-server.mjs`: public Node server. Other enquiry/desk/AI scripts are local pilots and are not connected to public intake.
- `tests`: validation, pricing, server, privacy and pilot checks.
- `owner-inputs`: rates, catalogue, genuine content and commercial inputs still needed.
- `workdone.md`: chronological history; REDESIGN-V12/13/14 and earlier handover documents are historical references.

npm and package-lock.json are the dependency source of truth. The unused Bun lockfile, spare UI templates and obsolete Worker configuration have been removed. Keep private runtime data, credentials, caches, dependencies and generated build folders out of source handovers.

## Confirmed contacts

sales@luxeinfra.in, copied to infoluxeinfra@gmail.com. WhatsApp +91 9026271638; second call number +91 7678432743. Service areas: Uttar Pradesh, Delhi NCR and Bengaluru.

No live hosting, Lovable project or GoDaddy DNS was changed by this cleanup.
