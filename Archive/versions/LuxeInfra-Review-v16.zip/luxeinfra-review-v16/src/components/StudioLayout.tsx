import { InspirationLink } from "./InspirationLink";
import { Link } from "@tanstack/react-router";
import { useState, useRef, useEffect } from "react";
import { ChevronDown, Menu, X, Phone, MessageCircle, Handshake } from "lucide-react";
import { PromotionBar } from "./Campaigns";
import { getFestiveState } from "@/lib/campaigns";
import { business } from "@/lib/business";
import { spaces } from "@/lib/spaces";
import { publishedProjects } from "@/lib/owner-content";
import logo from "@/assets/luxe-infra-logo.png";

export function StudioHeader() {
  const [open, setOpen] = useState(false);
  const [roomsOpen, setRoomsOpen] = useState(false);
  const menu = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    function close(event: PointerEvent) {
      if (menu.current && !menu.current.contains(event.target as Node)) setRoomsOpen(false);
    }
    function escape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
        if (roomsOpen) {
          setRoomsOpen(false);
          trigger.current?.focus();
        }
      }
    }
    document.addEventListener("pointerdown", close);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("pointerdown", close);
      document.removeEventListener("keydown", escape);
    };
  }, [roomsOpen]);
  const links = [
    ["/materials", "Materials"],
    ["/testimonials", "Reviews"],
    ["/how-it-works", "Our process"],
    ["/reimagine", "Room studio"],
    ["/about", "About us"],
  ] as const;
  return (
    <header className="studio-header lx-header">
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <PromotionBar />
      <div className="studio-nav wrap">
        <Link to="/" aria-label="LuxeInfra home" className="brand">
          <img src={logo} alt="" width="44" height="42" />
          <span>
            LUXE<span className="brand-light">INFRA</span>
            <small>INTERIORS, CONSIDERED.</small>
          </span>
        </Link>
        <nav aria-label="Main navigation" className="desktop-nav">
          <div
            className="lx-space-menu"
            ref={menu}
            onBlur={(event) => {
              if (!event.currentTarget.contains(event.relatedTarget as Node)) setRoomsOpen(false);
            }}
          >
            <button
              ref={trigger}
              className="lx-nav-trigger"
              onClick={() => setRoomsOpen(!roomsOpen)}
              aria-expanded={roomsOpen}
              aria-controls="spaces-menu"
            >
              Explore spaces <ChevronDown size={14} />
            </button>
            {roomsOpen && (
              <div className="lx-mega" id="spaces-menu">
                <div>
                  <span className="eyebrow">MAKE ROOM FOR YOUR IDEAS</span>
                  <h2>
                    Find your
                    <br />
                    <em>kind of home.</em>
                  </h2>
                  <Link
                    to="/design-ideas"
                    onClick={() => setRoomsOpen(false)}
                    className="lx-underlink"
                  >
                    Explore all inspiration
                  </Link>
                </div>
                <div className="lx-mega-links">
                  {spaces.map((space) => (
                    <Link
                      key={space.slug}
                      to="/design-ideas/$category"
                      params={{ category: space.slug }}
                      onClick={() => setRoomsOpen(false)}
                    >
                      {space.title}
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
          {links.map(([to, label]) => (
            <Link key={to} to={to} activeProps={{ className: "active" }}>
              {label}
            </Link>
          ))}
          <Link to="/estimate">Cost calculator</Link>
          {!!publishedProjects.length && <Link to="/projects">Our work</Link>}
        </nav>
        <div className="nav-actions">
          <InspirationLink compact />
          <Link to="/callback" className="button compact lx-nav-budget">
            <Phone size={16} /> Get a quote
          </Link>
          <button
            className="menu-toggle"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen(!open)}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
      <nav className="lc-category-nav" aria-label="Room collections">
        <div className="wrap">
          {["full-home", "kitchen", "wardrobe", "bedroom", "living", "kids"].map((slug) => {
            const space = spaces.find((s) => s.slug === slug)!;
            return (
              <Link to="/design-ideas/$category" params={{ category: slug }} key={slug}>
                {slug === "full-home"
                  ? "Full home interiors"
                  : slug === "kitchen"
                    ? "Modular kitchens"
                    : space.title.replace(" & storage", "")}
              </Link>
            );
          })}
          <Link to="/find-your-style">Find your style</Link>
          <Link to="/partner-with-us" className="lc-network-link">
            <Handshake size={14} /> Partner with us
          </Link>
        </div>
      </nav>
      {open && (
        <nav id="mobile-menu" className="mobile-nav" aria-label="Mobile navigation">
          <Link to="/design-ideas" onClick={() => setOpen(false)}>
            Explore spaces
          </Link>
          {links.map(([to, label]) => (
            <Link key={to} to={to} onClick={() => setOpen(false)}>
              {label}
            </Link>
          ))}
          <Link to="/estimate" onClick={() => setOpen(false)}>
            Explore your budget
          </Link>
          <Link to="/callback" onClick={() => setOpen(false)}>
            Talk to the studio
          </Link>
          <Link to="/find-your-style" onClick={() => setOpen(false)}>
            Find your style
          </Link>
          <Link to="/my-inspiration" onClick={() => setOpen(false)}>
            Saved inspiration
          </Link>
          <Link to="/contact" onClick={() => setOpen(false)}>
            Contact
          </Link>
          {getFestiveState() !== "unavailable" && (
            <Link to="/offers" onClick={() => setOpen(false)}>
              Festive offer
            </Link>
          )}
          <Link to="/partner-with-us" onClick={() => setOpen(false)}>
            Partner with us / Join us
          </Link>
        </nav>
      )}
    </header>
  );
}
export function StudioFooter({ forPartners = false }: { forPartners?: boolean }) {
  return (
    <footer className="studio-footer lx-footer">
      <div className="wrap lx-footer-invite">
        <div>
          <span className="eyebrow">
            {forPartners
              ? "LET’S FIND A WAY TO WORK TOGETHER"
              : "EVERY BEAUTIFUL HOME STARTS SOMEWHERE"}
          </span>
          <h2>
            {forPartners ? "Good ideas." : "Shall we start"}
            <br />
            {forPartners ? (
              "Great company."
            ) : (
              <>
                with <em>yours?</em>
              </>
            )}
          </h2>
        </div>
        <div>
          {forPartners ? (
            <a href="#partner-enquiry" className="button light">
              <Handshake size={17} /> Start a partnership conversation
            </a>
          ) : (
            <>
              <Link to="/callback" className="button light">
                <Phone size={17} /> Let’s talk interiors
              </Link>
              <Link to="/estimate" className="lx-footer-budget">
                Or explore your budget
              </Link>
            </>
          )}
        </div>
      </div>
      <div className="wrap lx-footer-grid">
        <div>
          <strong className="lx-footer-wordmark">
            LUXE<span>INFRA</span>
          </strong>
          <p>
            Considered spaces.
            <br />
            Everyday living. Personally yours.
          </p>
          <a href={business.whatsapp} target="_blank" rel="noreferrer">
            <MessageCircle size={17} /> Chat on WhatsApp
          </a>
        </div>
        <div>
          <h3>Explore</h3>
          <Link to="/design-ideas">Spaces & inspiration</Link>
          <Link to="/materials">Materials guide</Link>
          <Link to="/find-your-style">Find your style</Link>
          <Link to="/reimagine">Room studio</Link>
          <Link to="/testimonials">Reviews & client stories</Link>
        </div>
        <div>
          <h3>Plan with us</h3>
          <Link to="/estimate">Explore your budget</Link>
          <Link to="/callback">Request a conversation</Link>
          <Link to="/how-it-works">Our process</Link>
          <Link to="/project-brief">Detailed project brief</Link>
          {getFestiveState() !== "unavailable" && <Link to="/offers">Festive offer</Link>}
          <Link to="/partner-with-us">Partner with us / Join us</Link>
        </div>
        <div>
          <h3>Let’s connect</h3>
          <a href={business.phoneHref}>{business.phone}</a>
          <a href={business.secondaryPhoneHref}>{business.secondaryPhone}</a>
          <a href={`mailto:${business.email}`}>{business.email}</a>
          <a href={`mailto:${business.alternateEmail}`}>{business.alternateEmail}</a>
          <p>Uttar Pradesh · Delhi NCR · Bengaluru</p>
        </div>
      </div>
      <div className="wrap footer-bottom">
        <span>© {new Date().getFullYear()} LuxeInfra</span>
        <div>
          <Link to="/about">About us</Link>
          <Link to="/contact">Contact</Link>
          <Link to="/privacy">Privacy</Link>
        </div>
        <span>Interiors, considered.</span>
      </div>
    </footer>
  );
}
export function SectionTitle({
  kicker,
  title,
  text,
}: {
  kicker: string;
  title: string;
  text?: string;
}) {
  return (
    <div className="section-title">
      <span className="eyebrow">{kicker}</span>
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </div>
  );
}
export function PlanLink({
  children = "Explore my options",
  scope,
}: {
  children?: React.ReactNode;
  scope?: string;
}) {
  return (
    <Link to="/plan" search={{ scope }} className="button">
      {children}
    </Link>
  );
}
