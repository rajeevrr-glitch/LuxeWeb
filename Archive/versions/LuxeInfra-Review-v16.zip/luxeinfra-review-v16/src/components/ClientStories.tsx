import { Link } from "@tanstack/react-router";
import { MessageCircle, Quote } from "lucide-react";
import { publishedProjects, clientReviews } from "@/lib/owner-content";
import { selectReviewContent } from "@/lib/review-content";
import { business } from "@/lib/business";
import image from "@/assets/ideas/living/02.jpg";

export function ClientStories({
  kind = "all",
  page = false,
}: {
  kind?: "all" | "projects" | "reviews";
  page?: boolean;
}) {
  const projects = kind === "reviews" ? [] : publishedProjects;
  const reviews = selectReviewContent(
    clientReviews,
    import.meta.env.VITE_CONTENT_PREVIEW === "true",
  );
  if (kind === "projects" && !projects.length) return null;
  return (
    <>
      {!!projects.length && (
        <section className="wrap lc-section lx-client-stories">
          <span className="lc-kicker">THE PROJECT JOURNAL</span>
          <h2>Spaces with a personal story.</h2>
          <div className="lx-scope-grid">
            {projects.map((project) => (
              <article key={project.id}>
                <img src={project.image} alt={project.imageAlt} loading="lazy" />
                <span className="eyebrow">
                  {project.city} · {project.scope}
                </span>
                <h3>{project.title}</h3>
                <p>{project.story}</p>
              </article>
            ))}
          </div>
        </section>
      )}
      {kind !== "projects" && (
        <section
          className={`lc-stories${page ? " lc-stories-page" : ""}`}
          id="client-stories"
          aria-labelledby="stories-title"
        >
          <div className="wrap lc-section">
            <div className="lc-stories-heading">
              <div className="lc-stories-intro">
                <span className="lc-kicker">
                  <MessageCircle size={17} /> WORDS FROM HOME
                </span>
                {page ? (
                  <h1 id="stories-title">Know it from the people who live it.</h1>
                ) : (
                  <h2 id="stories-title">Know it from the people who live it.</h2>
                )}
                <p>
                  A home is more than the day it’s finished. It’s how it feels to live in it, every
                  day after.
                </p>
                {reviews.mode === "sample" && (
                  <p className="lc-stories-preview">
                    <strong>Layout preview</strong> These are example stories for design approval,
                    not real customer testimonials.
                  </p>
                )}
                {reviews.mode === "empty" && (
                  <p className="lc-stories-empty-note">
                    Approved client stories will appear here. Explore the ideas that could become
                    part of your own.
                  </p>
                )}
                {!page && (
                  <Link to="/testimonials" className="button secondary">
                    Explore client stories
                  </Link>
                )}
              </div>
              <div className="lc-stories-image">
                <img
                  src={image}
                  alt="Living room design inspiration, not a project associated with these stories"
                  loading="lazy"
                  width="800"
                  height="600"
                />
                <span>THE EVERYDAY IS THE REAL DESIGN STORY.</span>
              </div>
            </div>
            {reviews.cards.length > 0 ? (
              <div className="lc-story-cards">
                {reviews.cards.map((review) => (
                  <figure key={review.id} id={review.id}>
                    <div className="lc-story-top">
                      <span>{review.scope}</span>
                      <Quote size={25} strokeWidth={1.4} aria-hidden="true" />
                    </div>
                    {reviews.mode === "sample" && (
                      <span className="lc-story-sample">SAMPLE REVIEW · FOR LAYOUT APPROVAL</span>
                    )}
                    <h3>{review.title}</h3>
                    <blockquote>“{review.quote}”</blockquote>
                    <figcaption>
                      <span className="lc-story-monogram" aria-hidden="true">
                        {reviews.mode === "sample" ? "L" : review.byline.slice(0, 1)}
                      </span>
                      <span>
                        <strong>{review.byline}</strong>
                        <small>
                          {review.location ||
                            (reviews.mode === "sample"
                              ? "Replace with an approved client review"
                              : review.scope)}
                        </small>
                      </span>
                    </figcaption>
                  </figure>
                ))}
              </div>
            ) : (
              <div className="lc-story-invitation">
                <div>
                  <MessageCircle size={23} />
                  <h3>Have a LuxeInfra story to share?</h3>
                  <p>We’d love to hear about your space and the details that matter to you.</p>
                </div>
                <a
                  href={`mailto:${business.email}?subject=${encodeURIComponent("My LuxeInfra experience")}`}
                  className="button"
                >
                  Share your experience
                </a>
              </div>
            )}
            {page && (
              <div className="lc-stories-next">
                <span>Your next chapter starts with a conversation.</span>
                <Link to="/callback" className="button">
                  Talk about my home
                </Link>
              </div>
            )}
          </div>
        </section>
      )}
    </>
  );
}
