// Read-only checks of the built release, without sending any customer messages.
import assert from "node:assert/strict";
import { access } from "node:fs/promises";
import path from "node:path";
import handler from "../dist/server/server.js";

const review = process.argv.includes("--review");
const routes = [
  "/",
  "/offers",
  "/partner-with-us",
  "/partner-with-us?role=careers",
  "/callback?offer=festive-15",
  "/estimate",
  "/estimate?configuration=2%20BHK",
  "/estimate?module=Wardrobes",
  "/callback?scope=Selected%20rooms&room=Master%20bedroom",
  "/callback?module=Kitchen&design=kitchen-1",
  "/callback?scope=unrecognised&design=unknown",
  "/plan",
  "/project-brief",
  "/design-ideas",
  "/design-ideas/kitchen",
  "/design-ideas/bedroom",
  "/materials",
  "/how-it-works",
  "/reimagine",
  "/about",
  "/contact",
  "/privacy",
  "/testimonials",
];
const assets = new Set();
for (const route of routes) {
  let response = await handler.fetch(new Request("http://localhost" + route));
  if (route === "/callback?scope=unrecognised&design=unknown") {
    assert.equal(response.status, 307, "unknown design is removed from the URL");
    const destination = new URL(response.headers.get("location"), "http://localhost");
    assert.equal(destination.origin, "http://localhost");
    assert.equal(destination.pathname, "/callback");
    assert.equal(destination.searchParams.has("design"), false);
    response = await handler.fetch(new Request(destination));
  }
  assert.equal(response.status, 200, route);
  const html = await response.text();
  assert.doesNotMatch(html, /This page didn't load/);
  assert.equal((html.match(/<h1[\s>]/g) || []).length, 1, "one main heading: " + route);
  const canonical = html.match(/<link rel="canonical" href="([^"]+)"/);
  assert.equal(canonical?.[1], "https://luxeinfra.in" + route.split("?")[0], "canonical: " + route);
  assert.match(html, /property="og:image" content="https:\/\/luxeinfra.in\/assets\//);
  if (route === "/") {
    assert.doesNotMatch(html, /class="lw-launcher"/);
    assert.match(html, /Partner with LuxeInfra/);
    assert.match(html, /id="client-stories"/);
    assert.match(html, /href="\/testimonials"/);
    assert.equal(html.includes("SAMPLE REVIEW"), review);
    assert.equal(html.includes("Proposed festive offer"), review);
    assert.doesNotMatch(html.match(/<header[\s\S]*?<\/header>/)?.[0] || "", /Delhi NCR|Bengaluru/);
  }
  if (
    [
      "/estimate",
      "/callback?offer=festive-15",
      "/privacy",
      "/partner-with-us",
      "/plan",
      "/project-brief",
      "/reimagine",
    ].includes(route)
  )
    assert.doesNotMatch(html, /Open your home quote form/);
  if (route === "/offers") {
    assert.equal(html.includes("not open for booking yet"), review);
    assert.equal(html.includes("There isn’t a bookable festive offer"), !review);
  }
  if (route === "/partner-with-us?role=careers") assert.match(html, /value="careers" selected/);
  if (route === "/callback?offer=festive-15")
    assert.equal(html.includes("Festive offer preview"), review);
  if (route === "/testimonials") {
    assert.match(html, /Know it from the people who live it/);
    assert.equal(html.includes("SAMPLE REVIEW"), review);
    if (!review) assert.match(html, /Approved client stories will appear here/);
  }
  if (route === "/estimate") {
    assert.match(html, /What kind of home is yours/);
    assert.match(html, /1 RK/);
    assert.doesNotMatch(html, /autoComplete="(?:name|tel)"/i);
    assert.match(html, /does not give an instant price/);
    assert.match(html, /STEP 1 OF 3/);
    assert.doesNotMatch(html, /Room collections/);
  }
  if (route === "/estimate?configuration=2%20BHK") {
    assert.match(html, /Up to 800 sq ft/);
    assert.match(html, /Above 800 sq ft/);
    assert.match(html, /Not sure yet/);
  }
  if (route === "/estimate?module=Wardrobes") {
    assert.match(html, /Choose one, or bring both together/);
    assert.doesNotMatch(html, /Your home type/);
  }
  if (route === "/callback?scope=Selected%20rooms&room=Master%20bedroom") {
    assert.match(html, /Master bedroom/);
    assert.match(html, /autoComplete="name"/i);
    assert.doesNotMatch(html, /What are you planning/);
  }
  if (route === "/callback?module=Kitchen&design=kitchen-1") {
    assert.match(html, /Design reference included/);
    assert.match(html, /autoComplete="name"/i);
  }
  if (route === "/callback?scope=unrecognised&design=unknown") {
    assert.match(html, /What are you planning/);
    assert.doesNotMatch(html, /Design reference included/);
  }
  for (const match of html.matchAll(/(?:src|href)="(\/assets\/[^"?#]+)[^"\s]*"/g))
    assets.add(match[1]);
}
for (const asset of assets) await access(path.join("dist/client", decodeURIComponent(asset)));
assert.equal((await handler.fetch(new Request("http://localhost/not-a-real-page"))).status, 404);
console.log(
  JSON.stringify({
    mode: review ? "review" : "public",
    routes: routes.length,
    builtAssets: assets.size,
    offerGate: "passed",
    partnerDeepLink: "passed",
    missingPage: 404,
  }),
);
