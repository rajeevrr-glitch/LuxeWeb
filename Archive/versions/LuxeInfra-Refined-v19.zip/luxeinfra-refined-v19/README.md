# LuxeInfra website

UI refinement version 19 — 23 October 2026. Read UI-REFINEMENTS-V19.md for implemented audit fixes, QA-REPORT-V19.md for checks and owner-inputs/AFTER-UI-AUDIT-V19.md for missing business inputs. LAUNCH-CHECKLIST.md and LAUNCH-README.md cover deployment decisions. The complete history is in workdone.md; older version reports are historical.

## Run locally

Requires Node.js 24 or later. Install dependencies with `npm ci`.

- `npm run dev`: design development on port 5173, with the separate local-only AI/enquiry pilot services.
- `npm run build` then `npm start`: public-mode site on port 3000. Unapproved promotions and numerical prices are inactive.
- `npm run build:review` then `npm start`: local review with the proposed festive offer and clearly labelled sample client stories. Do not deploy this mode publicly.
- `npm run lint`, `npm run typecheck`, `npm test`, `npm run format:check`: quality checks.
- `node scripts/verify-redesign.mjs`: checks a public build; add `--review` after a review build.

Start-release.cmd builds and opens the local public release process; Start-preview.cmd starts development. Keep the terminal running while viewing the site. These commands do not publish it.

## Current visitor journeys

Room inspiration and saved ideas; style discovery; materials guidance; room-specific project planning; short quote enquiries; a budget/scope planner; room-photo briefing; and partnership/career introductions.

The planner begins with BHK/size and relevant interior choices. While approved rates are unavailable, it shows a scope summary without collecting contact details. Its optional quote action carries the selections forward. Numerical budgets and their later contact/result journey remain gated by approved rates. Quick quotes skip the project chooser when valid context is already supplied, otherwise start with project cards. Optional email/call preferences are page-local; delivery is a manual app handoff.

The welcome invitation opens once per tab session after 12 seconds plus browsing exploration, or after a 30-second visit. It waits around menus/dialogs/typing and excludes active form, privacy, contact and style-quiz journeys. The header quote action reopens it on eligible browsing pages; there is no floating invitation covering content. Readable mobile choices intentionally scroll within the panel. Personal fields clear on close; only a non-personal seen flag is stored. `/?welcome=1` explicitly previews the invitation. See QA-REPORT-V19.md for actual coverage.

Short enquiries prepare WhatsApp/email drafts. The visitor reviews and sends them. Files must be attached in the selected app. The website does not automatically send messages, upload customer files or confirm receipt.

Numerical estimates need approved rates. Festive offers need approved dates and terms. The homepage and permanent Reviews navigation now show a client-stories section even before genuine reviews are supplied. The normal public build uses only approved, permissioned reviews, or an invitation to share an experience. Local review mode alone shows labelled layout examples. Public AI generation is disabled.

## Code and notes

- `src/routes`: page journeys; `src/components`: shared interface; `src/lib`: business details, room logic, pricing and publication controls.
- `src/styles.css`, `studio.css`, `refinement.css`, `launch.css`, `commerce.css`, `campaigns.css`, `reviews.css`, `sales.css`, `welcome.css`, `usability.css`: ordered style layers for the retained theme and shared journeys/gallery refinements.
- `scripts/production-server.mjs`: public Node server. Other enquiry/desk/AI scripts are local pilots and are not connected to public intake.
- `tests`: validation, pricing, server, privacy and pilot checks.
- `owner-inputs`: rates, catalogue, genuine content and commercial inputs still needed.
- `workdone.md`: chronological history; REDESIGN-V12/13/14 and earlier handover documents are historical references.

npm and package-lock.json are the dependency source of truth. The unused Bun lockfile, spare UI templates and obsolete Worker configuration have been removed. Keep private runtime data, credentials, caches, dependencies and generated build folders out of source handovers.

## Confirmed contacts

sales@luxeinfra.in, copied to infoluxeinfra@gmail.com. WhatsApp +91 9026271638; second call number +91 7678432743. Service areas: Uttar Pradesh, Delhi NCR and Bengaluru.

No live hosting, Lovable project or GoDaddy DNS was changed by this cleanup.
