import { Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Calculator,
  Check,
  CheckCircle2,
  ChevronDown,
  Layers3,
  MessageCircle,
  Palette,
  Phone,
  Plus,
  Ruler,
  Sparkles,
} from "lucide-react";
import { PageShell } from "./PageShell";
import { ClientStories } from "./ClientStories";
import { SaveInspiration } from "./SaveInspiration";
import { FestiveFeature } from "./Campaigns";
import { planningJourney } from "@/lib/journey";
import { business, faqs } from "@/lib/business";
import { spaces, designsFor } from "@/lib/spaces";
import hero from "@/assets/hero-living.jpg";
import kitchen from "@/assets/ideas/kitchen/01.jpg";
import home from "@/assets/full-home.jpg";
import wardrobe from "@/assets/ideas/wardrobe/02.jpg";
import bedroom from "@/assets/ideas/bedroom/02.jpg";

const heroRooms = [
  {
    label: "Living, beautifully",
    image: hero,
    alt: "Warm living room with ivory seating, wood panelling and a large window",
  },
  { label: "Kitchens, thoughtfully", image: kitchen, alt: "Kitchen interior design inspiration" },
  { label: "Bedrooms, personally", image: bedroom, alt: "Bedroom interior design inspiration" },
];
const solutionCards = [
  {
    title: "Complete home interiors",
    tag: "THE BIG PICTURE",
    image: home,
    slug: "full-home",
    text: "A connected design for your kitchen, bedrooms, living spaces and all the details in between.",
    chips: ["Layouts", "Materials", "Room-by-room planning"],
  },
  {
    title: "Modular kitchens",
    tag: "MADE FOR YOUR EVERYDAY",
    image: kitchen,
    slug: "kitchen",
    text: "Make cooking, storage and movement feel effortless, with a layout that works around you.",
    chips: ["Cabinetry", "Storage", "Finishes"],
  },
  {
    title: "Wardrobes & storage",
    tag: "A PLACE FOR EVERYTHING",
    image: wardrobe,
    slug: "wardrobe",
    text: "Considered storage, from the way the doors open to the things you keep inside.",
    chips: ["Internal planning", "Hardware", "Personal style"],
  },
];
const galleryRooms = [
  { slug: "kitchen", title: "Kitchens" },
  { slug: "living", title: "Living rooms" },
  { slug: "bedroom", title: "Bedrooms" },
  { slug: "wardrobe", title: "Wardrobes" },
  { slug: "kids", title: "Kids’ rooms" },
  { slug: "pooja", title: "Pooja spaces" },
];
const shortcuts = [
  "full-home",
  "kitchen",
  "wardrobe",
  "bedroom",
  "living",
  "kids",
  "pooja",
  "office",
];

export function StudioHome() {
  const [heroIndex, setHeroIndex] = useState(0);
  const [interest, setInterest] = useState("Whole home");
  const [room, setRoom] = useState("kitchen");
  const [expanded, setExpanded] = useState(false);
  const allDesigns = designsFor(room);
  const designs = allDesigns.slice(0, expanded ? 6 : 3);
  const activeRoom = galleryRooms.find((item) => item.slug === room)!;
  const scope = interest === "Whole home" ? "Whole home" : "Modular interiors";
  const module =
    interest === "Kitchen" ? "Kitchen" : interest === "Wardrobes" ? "Wardrobes" : undefined;
  return (
    <PageShell>
      <section className="lc-hero wrap" aria-labelledby="home-title">
        <div className="lc-hero-scene">
          <img
            src={heroRooms[heroIndex].image}
            alt={heroRooms[heroIndex].alt}
            className="lc-hero-photo"
            width="1920"
            height="1080"
            fetchPriority="high"
          />
          <div className="lc-hero-overlay" />
          <span className="lc-photo-label">
            <span />
            {heroRooms[heroIndex].label}
          </span>
          <div className="lc-hero-copy">
            <span className="lc-overline">LUXEINFRA HOME INTERIORS</span>
            <h1 id="home-title">
              Home interiors.
              <br />
              Your space,
              <br />
              <span>considered.</span>
            </h1>
            <p>
              Kitchens, storage and complete homes. Explore your ideas, plan your scope and speak
              directly with our studio.
            </p>
            <p className="lc-service-coverage">Uttar Pradesh · Delhi NCR · Bengaluru</p>
            <Link to="/design-ideas" className="button light">
              Explore design ideas
            </Link>
          </div>
          <div className="lc-scene-switch" role="group" aria-label="Choose hero room">
            {heroRooms.map((item, i) => (
              <button
                key={item.label}
                aria-label={"Show " + item.label}
                aria-pressed={i === heroIndex}
                onClick={() => setHeroIndex(i)}
              >
                <img src={item.image} alt="" />
                <span>{["Living", "Kitchen", "Bedroom"][i]}</span>
              </button>
            ))}
          </div>
          <span className="lc-image-note">Design inspiration</span>
        </div>
        <div className="lc-hero-start">
          <span className="lc-kicker">
            <Sparkles size={15} /> YOUR HOME STARTS HERE
          </span>
          <h2>
            Great interiors.
            <br />A simple beginning.
          </h2>
          <p>What would you like to design?</p>
          <div className="lc-interest" role="group" aria-label="Choose your project">
            {[
              ["Whole home", home],
              ["Kitchen", kitchen],
              ["Wardrobes", wardrobe],
            ].map(([label, image]) => (
              <button
                key={label}
                aria-pressed={interest === label}
                onClick={() => setInterest(label)}
              >
                <img src={image} alt="" />
                <span>{label}</span>
                <span className="lc-radio">{interest === label && <Check size={12} />}</span>
              </button>
            ))}
          </div>
          <Link
            to="/callback"
            search={{ scope, module, room: interest === "Kitchen" ? "Kitchen" : undefined }}
            className="button lc-quote"
          >
            <Phone size={16} />
            Get a quote
          </Link>
          <Link to="/estimate" search={{ scope, module }} className="lc-budget-link">
            <Calculator size={17} />
            {planningJourney().label}
          </Link>
          <span className="lc-hero-small">
            Start with a conversation. No detailed brief needed.
          </span>
        </div>
      </section>
      <section className="wrap lc-room-shortcuts" aria-label="Browse rooms">
        {shortcuts.map((slug) => {
          const item = spaces.find((s) => s.slug === slug)!;
          return (
            <Link to="/design-ideas/$category" params={{ category: slug }} key={slug}>
              <img src={item.image} alt="" width="100" height="80" />
              <span>
                {slug === "full-home"
                  ? "Full home"
                  : slug === "office"
                    ? "Home office"
                    : slug === "kids"
                      ? "Kids’ rooms"
                      : slug === "pooja"
                        ? "Pooja spaces"
                        : item.title.replace(" & storage", "")}
              </span>
            </Link>
          );
        })}
      </section>
      <nav className="lc-benefit-strip" aria-label="A simpler way to start">
        <div className="wrap">
          <Link to="/my-inspiration">
            <CheckCircle2 size={23} />
            <span>
              <strong>Save what you love</strong>
              <small>Your ideas, in one shortlist</small>
            </span>
          </Link>
          <Link to="/estimate">
            <Layers3 size={23} />
            <span>
              <strong>Plan at your pace</strong>
              <small>No floor plan needed to begin</small>
            </span>
          </Link>
          <Link to="/contact">
            <MessageCircle size={23} />
            <span>
              <strong>Speak to the studio</strong>
              <small>WhatsApp, email or a direct call</small>
            </span>
          </Link>
        </div>
      </nav>

      <section className="wrap lc-section" aria-labelledby="solutions-title">
        <div className="lc-section-head">
          <div>
            <span className="lc-kicker">DESIGNED FOR THE WAY YOU LIVE</span>
            <h2 id="solutions-title">One home. So many possibilities.</h2>
            <p>Choose the space. We’ll help bring the possibilities together.</p>
          </div>
          <Link to="/services" className="lc-text-action">
            Explore our services
          </Link>
        </div>
        <div className="lc-solutions">
          {solutionCards.map((item) => (
            <article key={item.slug}>
              <Link
                to="/design-ideas/$category"
                params={{ category: item.slug }}
                className="lc-solution-photo"
              >
                <img
                  src={item.image}
                  alt={item.title + " inspiration"}
                  loading="lazy"
                  width="600"
                  height="400"
                />
                <span>{item.tag}</span>
              </Link>
              <div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
                <div className="lc-tags">
                  {item.chips.map((chip) => (
                    <span key={chip}>{chip}</span>
                  ))}
                </div>
                <Link
                  to="/design-ideas/$category"
                  params={{ category: item.slug }}
                  className="lc-text-action"
                >
                  Explore designs
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <ClientStories />
      <FestiveFeature />
      <section className="lc-gallery-section">
        <div className="wrap lc-section">
          <div className="lc-section-head">
            <div>
              <span className="lc-kicker">THE DESIGN GALLERY</span>
              <h2>Find a look you’d love to come home to.</h2>
              <p>Explore, save and bring your favourite ideas into the conversation.</p>
            </div>
            <Link to="/my-inspiration" className="lc-text-action">
              My saved ideas
            </Link>
          </div>
          <div className="lc-gallery-tabs" role="group" aria-label="Filter design inspiration">
            {galleryRooms.map((item) => (
              <button
                key={item.slug}
                aria-pressed={room === item.slug}
                onClick={() => {
                  setRoom(item.slug);
                  setExpanded(false);
                }}
              >
                {item.title}
              </button>
            ))}
          </div>
          <div className="lc-design-grid">
            {designs.map((design, i) => (
              <article key={design.id}>
                <div className="lc-design-photo">
                  <Link
                    to="/design-ideas/$category"
                    params={{ category: room }}
                    hash={design.id}
                    aria-label={"Explore " + design.title}
                  >
                    <img
                      src={design.image}
                      alt={design.title + " design inspiration"}
                      loading="lazy"
                      width="600"
                      height="450"
                    />
                  </Link>
                  <SaveInspiration item={design} compact />
                </div>
                <div className="lc-design-info">
                  <span>{activeRoom.title}</span>
                  <h3>Design {String(i + 1).padStart(2, "0")}</h3>
                  <Link to="/design-ideas/$category" params={{ category: room }} hash={design.id}>
                    View collection
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className="lc-gallery-bottom">
            <span>Illustrative design references, not completed LuxeInfra projects.</span>
            <button
              type="button"
              className="button secondary"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? "Show fewer designs" : "More " + activeRoom.title.toLowerCase()}
              <ChevronDown size={15} className={expanded ? "lc-rotated" : ""} />
            </button>
          </div>
        </div>
      </section>

      <section className="wrap lc-section">
        <div className="lc-cost-banner">
          <div>
            <span className="lc-kicker">PLAN YOUR SPACE. UNDERSTAND YOUR SCOPE.</span>
            <h2>
              From a few choices
              <br />
              to a clearer scope.
            </h2>
            <p>
              Choose your BHK, approximate size and interiors. Review your scope first, then decide
              whether to request a quote.
            </p>
            <span className="lc-cost-note">
              <CheckCircle2 size={15} />
              No contact details required to explore. Pricing follows a studio review.
            </span>
          </div>
          <div className="lc-calculators">
            {[
              { name: "Full home", image: home, scope: "Whole home", module: undefined },
              { name: "Kitchen", image: kitchen, scope: "Modular interiors", module: "Kitchen" },
              {
                name: "Wardrobes",
                image: wardrobe,
                scope: "Modular interiors",
                module: "Wardrobes",
              },
            ].map((item) => (
              <Link
                to="/estimate"
                search={{ scope: item.scope, module: item.module }}
                key={item.name}
              >
                <img src={item.image} alt="" loading="lazy" />
                <Calculator size={22} />
                <strong>{item.name}</strong>
                <span>{planningJourney().label}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="wrap lc-section lc-home-tools" aria-label="More ways to explore">
        <Link to="/find-your-style">
          <Palette size={26} />
          <h3>Find your style</h3>
          <p>A few visual choices to discover your design direction.</p>
          <span>Take the style quiz</span>
        </Link>
        <Link to="/materials">
          <Layers3 size={26} />
          <h3>Understand your materials</h3>
          <p>Know the questions to ask about boards, finishes and hardware.</p>
          <span>Explore the materials guide</span>
        </Link>
        <Link to="/reimagine">
          <Ruler size={26} />
          <h3>Start with your room</h3>
          <p>Bring a photo and your ideas together in a room brief.</p>
          <span>Open room studio</span>
        </Link>
      </section>

      <section className="lc-process">
        <div className="wrap lc-section">
          <div className="lc-section-head">
            <div>
              <span className="lc-kicker">FROM IDEAS TO YOUR EVERYDAY</span>
              <h2>Your home journey, made clearer.</h2>
            </div>
            <Link to="/how-it-works" className="lc-text-action">
              How it works
            </Link>
          </div>
          <div className="lc-steps">
            {[
              ["01", "Let’s talk", "Your space, your ideas and the work you’re considering."],
              [
                "02",
                "Shape the design",
                "Explore layouts, specifications and your itemised scope.",
              ],
              ["03", "Agree the details", "Confirm the work, approvals and project schedule."],
              [
                "04",
                "Bring it home",
                "Review the finished work, care guidance and applicable support.",
              ],
            ].map(([n, title, text]) => (
              <div key={n}>
                <span>{n}</span>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <div className="wrap lc-partner-note">
        <span>Architect, designer or property professional?</span>
        <Link to="/partner-with-us">Partner with LuxeInfra</Link>
      </div>
      <section className="wrap lc-section lc-faq">
        <div className="lc-section-head">
          <div>
            <span className="lc-kicker">YOUR QUESTIONS, ANSWERED</span>
            <h2>Before we get started.</h2>
          </div>
          <a href={business.phoneHref} className="lc-text-action">
            Speak to the studio
          </a>
        </div>
        <div>
          {faqs.map(([q, a]) => (
            <details key={q}>
              <summary>
                {q}
                <Plus size={17} />
              </summary>
              <p>{a}</p>
            </details>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
