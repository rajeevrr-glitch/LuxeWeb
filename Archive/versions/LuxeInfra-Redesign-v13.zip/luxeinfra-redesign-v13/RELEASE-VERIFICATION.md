# Release verification — version 13

21 October 2026. Local service-led UI redesign; no public deployment.

Passed:
- Final production build and TypeScript checking.
- All 22 automated checks for pricing guards, room-specific work, local enquiry/desk controls, pilot AI restrictions and production endpoint handling. No new tests that merely mirror visual styling were added.
- HTTP verification of 15 pages, including wardrobe-specific and 3 BHK entry URLs; 33 homepage image/style/script asset references returned 200. Gallery/scene/save controls and contextual links are present in the rendered page. Missing-page response is 404; public AI remains disabled.
- Dedicated task-only Chrome window: homepage composition, stronger typography, two-level navigation, companion quote selector and manual room thumbnails inspected. Wardrobe selection changes its quote/budget link and arrives at a wardrobe-only modular summary. A kitchen summary-image mismatch was identified and fixed in the final source/build.

Limits:
- User interaction was detected during subsequent browser actions. Further UI interaction was stopped; a full mobile/browser interaction review of version 13 (including gallery save/expand behavior) is still outstanding. Responsive styling and existing save logic are implemented; source/HTTP checks do not substitute for those remaining visual checks.
- Automatic approval rejected access to an unrelated private Chrome window. A separate local-preview window was opened for the permitted visual checks instead; no unrelated page content was read.
- The captured desktop-preview.jpg in task outputs is an intermediate budget-screen observation before the final summary-image fix, not a final homepage/mobile approval screenshot.
- Existing limits remain: actual rates, image rights, verified projects/reviews, catalogue, commercial terms, hosting and real message receipt. Automatic callback delivery and public AI are not enabled.

## Earlier version 12 verification

21 October 2026. Tested local redesign review build; no public deployment.

Passed on the final build:
- Production build and TypeScript checking.
- All 22 automated checks, including missing/expired/unsupported rates, exact units/specifications, safe measurements and whole-home bundle arithmetic. The server tests use temporary local ports; they were run with local network access after the sandbox denied those socket connections.
- HTTP checks: 20 pages/endpoints and 23 homepage asset references returned 200; unknown route returned 404; public AI status is disabled; public testimonials contain no sample reviews.
- Desktop browser: room navigation opens and Escape closes it; room edit changes its image/copy; modular scope/measurements/finish/result work; choices carry to the short enquiry; materials palette carries forward; invalid typed phone is rejected; valid test input produces correct WhatsApp and email To/CC links. No external messages were sent.
- Existing bedroom planning link enters the gateway and preserves Master bedroom in the selected-room estimate. The optional detailed brief remains a separate working route.
- Mobile viewport 390px: homepage, navigation, materials chapters/palettes and whole-home choices/result work. Measured content client/scroll widths both 375px (no horizontal overflow). Final homepage typography was refined after the first mobile check.
- Fresh-selection reset clears the new estimate choices. Existing saved inspiration is preserved.
- No errors recorded in the final homepage browser console.
- Screenshot evidence: outputs/redesign-v12/home-desktop.jpg, home-mobile.jpg and home-full.jpg in the task workspace. Desktop source package includes the preview images separately.

Limits: real prices, product catalogue, verified project/review content, media rights and commercial terms await owner input. Short enquiries use customer-sent WhatsApp/email; automatic receipt, staff assignment and notification delivery are not activated. Hosting, real inbox/WhatsApp receipt, public AI, Docker and end-to-end domain launch have not been tested. No accessibility certification, independent performance score or load-test result is claimed.

## Earlier version 11 verification

18 October 2026. This is a tested local release candidate, not an internet deployment.

Passed:
- All 17 automated tests after the dependency updates. Covers invalid room work, saved-choice migration, private files, local desk access, AI pilot controls and production endpoint restrictions.
- TypeScript checking after adapting the root error component to the framework's unknown error type.
- Production build using patched TanStack Start 1.168.60, React Router 1.170.41 and Vite 7.3.7. The later root edit changed a TypeScript annotation only, with no runtime output change.
- npm audit fix completed with 0 known vulnerabilities in the resulting dependency tree (18 October 2026).
- Production HTTP checks: 16 public routes/assets returned 200; unknown route returned 404. Includes planner, room studio, gallery/category, services, contact, privacy, sitemap, robots and favicon.
- Public testimonials response contains no example review copy.
- Browser: restored bedroom/bathroom choices, all five planner steps, correct review summary, contact consent, ready-to-send screen and edit flow.
- Downloaded synthetic brief inspected: room-specific work, city, contact and budget fields are correct.
- WhatsApp target and email To/CC verified from link destinations. No external message sent.
- Mobile width 390px: planner and ready screen controls present, no horizontal page overflow (scroll width 375px).

Remaining limits:
- Actual hosting account, domain/HTTPS/redirect setup and external email/WhatsApp receipt are not verified.
- Owner image-publication permissions, authentic testimonials and commercial terms remain pending.
- AI API keys were not activated and no paid provider call was made. Public AI remains disabled.
- Dockerfile is prepared but Docker build was not run here.
- No full accessibility certification or load testing has been performed.
