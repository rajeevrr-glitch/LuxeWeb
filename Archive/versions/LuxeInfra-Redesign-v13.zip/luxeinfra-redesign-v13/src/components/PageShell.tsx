import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Calculator, Phone } from "lucide-react";
import { StudioHeader as SiteHeader, StudioFooter as SiteFooter } from "./StudioLayout";

export function PageShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const showMobileActions = !["/estimate", "/callback", "/project-brief", "/reimagine"].includes(
    pathname,
  );
  return (
    <div
      className={`luxe-site luxe-commerce flex min-h-screen flex-col${showMobileActions ? " lc-has-mobile-actions" : ""}`}
    >
      <SiteHeader />
      <main id="main-content" className="flex-1">
        {children}
      </main>
      <SiteFooter />
      {showMobileActions && (
        <nav className="lc-mobile-actions" aria-label="Quick project actions">
          <Link to="/estimate">
            <Calculator size={18} />
            Explore budget
          </Link>
          <Link to="/callback">
            <Phone size={17} />
            Get a quote
          </Link>
        </nav>
      )}
    </div>
  );
}
