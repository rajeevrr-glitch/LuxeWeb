import { publishedProjects, publishedReviews } from "@/lib/owner-content";
export function ClientStories({ kind = "all" }: { kind?: "all" | "projects" | "reviews" }) {
  const projects = kind === "reviews" ? [] : publishedProjects;
  const reviews = kind === "projects" ? [] : publishedReviews;
  if (!projects.length && !reviews.length) return null;
  return (
    <section className="wrap lx-section lx-client-stories">
      <span className="eyebrow">LIFE, AT HOME</span>
      <h2>
        Real spaces.
        <br />
        <em>Personal stories.</em>
      </h2>
      {!!projects.length && (
        <div className="lx-scope-grid">
          {projects.map((project) => (
            <article key={project.id}>
              <img src={project.image} alt={project.imageAlt} loading="lazy" />
              <span className="eyebrow">
                {project.city} · {project.scope}
              </span>
              <h3>{project.title}</h3>
              <p>{project.story}</p>
            </article>
          ))}
        </div>
      )}
      {!!reviews.length && (
        <div className="lx-review-grid">
          {reviews.map((review) => (
            <figure key={review.id}>
              <blockquote>“{review.quote}”</blockquote>
              <figcaption>
                <strong>{review.name}</strong>
                <span>
                  {review.city} · {review.scope}
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      )}
    </section>
  );
}
